"""
Codec for encoding objects into the XRP Ledger's canonical binary format and
decoding them.
"""

from typing import Any, Dict, List, Optional, TypedDict, cast

from typing_extensions import Final, NotRequired

from xrpl.core.binarycodec.binary_wrappers.binary_parser import BinaryParser
from xrpl.core.binarycodec.types import AccountID, Hash256, STObject, UInt32, UInt64


def _num_to_bytes(num: int) -> bytes:
    return (num).to_bytes(4, byteorder="big", signed=False)


_TRANSACTION_SIGNATURE_PREFIX: Final[bytes] = _num_to_bytes(0x53545800)
_PAYMENT_CHANNEL_CLAIM_PREFIX: Final[bytes] = _num_to_bytes(0x434C4D00)
_TRANSACTION_MULTISIG_PREFIX: Final[bytes] = _num_to_bytes(0x534D5400)
_BATCH_PREFIX: Final[bytes] = _num_to_bytes(0x42434800)
# Role-specific signing prefixes introduced by fixCleanup3_4_0.
_COUNTERPARTY_TRANSACTION_SIGNATURE_PREFIX: Final[bytes] = _num_to_bytes(0x43505400)
_COUNTERPARTY_TRANSACTION_MULTISIG_PREFIX: Final[bytes] = _num_to_bytes(0x43504D00)
_SPONSOR_TRANSACTION_SIGNATURE_PREFIX: Final[bytes] = _num_to_bytes(0x53504E00)
_SPONSOR_TRANSACTION_MULTISIG_PREFIX: Final[bytes] = _num_to_bytes(0x53504D00)


def encode(json: Dict[str, Any]) -> str:
    """
    Encode a transaction or other object into the canonical binary format.

    Args:
        json: A JSON-like dictionary representation of an object.

    Returns:
        The binary-encoded object, as a hexadecimal string.
    """
    return _serialize_json(json)


def encode_for_signing(json: Dict[str, Any]) -> str:
    """
    Encode a transaction into binary format in preparation for signing. (Only
    encodes fields that are intended to be signed.)

    Args:
        json: A JSON-like dictionary representation of a transaction.

    Returns:
        The binary-encoded transaction, ready to be signed.
    """
    return _serialize_json(
        json,
        prefix=_TRANSACTION_SIGNATURE_PREFIX,
        signing_only=True,
    )


def encode_for_signing_claim(json: Dict[str, Any]) -> str:
    """
    Encode a `payment channel <https://xrpl.org/payment-channels.html>`_ Claim
    to be signed.

    Args:
        json: A JSON-like dictionary representation of a Claim.

    Returns:
        The binary-encoded claim, ready to be signed.
    """
    prefix = _PAYMENT_CHANNEL_CLAIM_PREFIX
    channel = Hash256.from_value(json["channel"])
    amount = UInt64.from_value(int(json["amount"]))

    buffer = prefix + bytes(channel) + bytes(amount)
    return buffer.hex().upper()


class BatchSigningDict(TypedDict):
    """
    A TypedDict describing the data of a Batch transaction that is intended to be
    signed by a ``BatchSigner`` (XLS-56 ``Batch`` V1_1).
    """

    account: str
    sequence: int
    flags: int
    transaction_ids: List[str]
    batch_account: str
    signer_account: NotRequired[str]


def encode_for_signing_batch(json: BatchSigningDict) -> str:
    """
    Encode a Batch transaction's data to be signed by a ``BatchSigner``.

    Serializes the XLS-56 Batch V1_1 signing payload::

        BATCH_PREFIX | Account | Sequence | Flags | len(transaction_ids)
            | transaction_ids[] | batch_account [ | signer_account ]

    The outer ``account`` and ``sequence`` bind the signature to a specific Batch,
    preventing it from being replayed under a different outer account or sequence.

    Args:
        json: A dictionary describing the Batch signing data. Requires the outer
            Batch ``account``, its ``sequence`` value (the ``Sequence``, or the
            ``TicketSequence`` value when a ticket is used), ``flags``, the list of
            inner ``transaction_ids``, and the ``batch_account`` (the
            ``BatchSigner.Account`` the signature binds to). ``signer_account`` is the
            inner ``Signers`` entry account for a multi-signed ``BatchSigner``.

    Returns:
        The binary-encoded Batch signing data, as an uppercase hex string.
    """
    transaction_ids = json["transaction_ids"]

    buffer = _BATCH_PREFIX
    buffer += bytes(AccountID.from_value(json["account"]))
    buffer += bytes(UInt32.from_value(json["sequence"]))
    buffer += bytes(UInt32.from_value(json["flags"]))
    buffer += bytes(UInt32.from_value(len(transaction_ids)))
    for tx in transaction_ids:
        buffer += bytes(Hash256.from_value(tx))

    buffer += bytes(AccountID.from_value(json["batch_account"]))
    # The inner signer account is only present for a multi-signed BatchSigner.
    signer_account = json.get("signer_account")
    if signer_account is not None:
        buffer += bytes(AccountID.from_value(signer_account))

    return buffer.hex().upper()


def encode_for_multisigning(json: Dict[str, Any], signing_account: str) -> str:
    """
    Encode a transaction into binary format in preparation for providing one
    signature towards a multi-signed transaction.
    (Only encodes fields that are intended to be signed.)

    Args:
        json: A JSON-like dictionary representation of a transaction.
        signing_account: The address of the signer who'll provide the signature.

    Returns:
        A hex string of the encoded transaction.
    """
    signing_account_id = bytes(AccountID.from_value(signing_account))

    return _serialize_json(
        json,
        prefix=_TRANSACTION_MULTISIG_PREFIX,
        suffix=signing_account_id,
        signing_only=True,
    )


def encode_for_signing_counterparty(json: Dict[str, Any]) -> str:
    """
    Encode a transaction for signing by the counterparty.

    Under ``fixCleanup3_4_0`` a counterparty signature covers a distinct signing
    prefix so it cannot be replayed as a first-party signature.

    Args:
        json: A JSON-like dictionary representation of a transaction.

    Returns:
        The binary-encoded transaction, ready to be signed.
    """
    return _serialize_json(
        json,
        prefix=_COUNTERPARTY_TRANSACTION_SIGNATURE_PREFIX,
        signing_only=True,
    )


def encode_for_multisigning_counterparty(
    json: Dict[str, Any], signing_account: str
) -> str:
    """
    Encode a transaction for multi-signing by the counterparty
    (``fixCleanup3_4_0``).

    Args:
        json: A JSON-like dictionary representation of a transaction.
        signing_account: The address of the signer who'll provide the signature.

    Returns:
        A hex string of the encoded transaction.
    """
    signing_account_id = bytes(AccountID.from_value(signing_account))

    return _serialize_json(
        json,
        prefix=_COUNTERPARTY_TRANSACTION_MULTISIG_PREFIX,
        suffix=signing_account_id,
        signing_only=True,
    )


def encode_for_signing_sponsor(json: Dict[str, Any]) -> str:
    """
    Encode a transaction for signing by the sponsor.

    Under ``fixCleanup3_4_0`` a sponsor signature covers a distinct signing
    prefix so it cannot be replayed as a first-party signature.

    Args:
        json: A JSON-like dictionary representation of a transaction.

    Returns:
        The binary-encoded transaction, ready to be signed.
    """
    return _serialize_json(
        json,
        prefix=_SPONSOR_TRANSACTION_SIGNATURE_PREFIX,
        signing_only=True,
    )


def encode_for_multisigning_sponsor(json: Dict[str, Any], signing_account: str) -> str:
    """
    Encode a transaction for multi-signing by the sponsor (``fixCleanup3_4_0``).

    Args:
        json: A JSON-like dictionary representation of a transaction.
        signing_account: The address of the signer who'll provide the signature.

    Returns:
        A hex string of the encoded transaction.
    """
    signing_account_id = bytes(AccountID.from_value(signing_account))

    return _serialize_json(
        json,
        prefix=_SPONSOR_TRANSACTION_MULTISIG_PREFIX,
        suffix=signing_account_id,
        signing_only=True,
    )


def decode(buffer: str) -> Dict[str, Any]:
    """
    Decode a transaction from binary format to a JSON-like dictionary
    representation.

    Args:
        buffer: The encoded transaction binary, as a hexadecimal string.

    Returns:
        A JSON-like dictionary representation of the transaction.
    """
    parser = BinaryParser(buffer)
    parsed_type = cast(STObject, parser.read_type(STObject))
    return parsed_type.to_json()


def _serialize_json(
    json: Dict[str, Any],
    prefix: Optional[bytes] = None,
    suffix: Optional[bytes] = None,
    signing_only: bool = False,
) -> str:
    buffer = b""
    if prefix is not None:
        buffer += prefix

    buffer += bytes(STObject.from_value(json, signing_only))

    if suffix is not None:
        buffer += suffix

    return buffer.hex().upper()
