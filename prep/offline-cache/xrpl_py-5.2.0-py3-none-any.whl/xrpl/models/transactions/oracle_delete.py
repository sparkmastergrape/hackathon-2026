"""Model for OracleDelete transaction type."""

from __future__ import annotations

from dataclasses import dataclass, field

from xrpl.models.required import REQUIRED
from xrpl.models.transactions.transaction import Transaction
from xrpl.models.transactions.types import TransactionType


@dataclass(frozen=True, kw_only=True)
class OracleDelete(Transaction):
    """Delete an Oracle ledger entry."""

    account: str = REQUIRED
    """This account must match the account in the Owner field of the Oracle object."""

    oracle_document_id: int = REQUIRED
    """A unique identifier of the price oracle for the Account."""

    transaction_type: TransactionType = field(
        default=TransactionType.ORACLE_DELETE,
        init=False,
    )
