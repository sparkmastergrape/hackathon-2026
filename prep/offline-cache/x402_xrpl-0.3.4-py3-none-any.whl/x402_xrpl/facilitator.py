from __future__ import annotations

import base64
import json
import re
from dataclasses import dataclass
from typing import Any, Mapping, Optional

import httpx

from .types import (
    FacilitatorSupportedResponse,
    PaymentPayload,
    PaymentRequirements,
    PaymentVerifyResponse,
    SettlementResponse,
)


def _raise_for_status(response: httpx.Response) -> None:
    """Keep status/response access without putting upstream bodies or URLs in logs."""
    try:
        response.raise_for_status()
    except httpx.HTTPStatusError:
        request_id = response.headers.get("X-Request-ID") or response.headers.get("X-Correlation-ID")
        suffix = f":{request_id}" if request_id and re.fullmatch(r"[A-Za-z0-9._:-]{1,128}", request_id) else ""
        raise httpx.HTTPStatusError(
            f"facilitator_http_error:{response.status_code}{suffix}",
            request=response.request, response=response,
        ) from None


@dataclass(frozen=True)
class FacilitatorClientOptions:
    base_url: str
    timeout_seconds: float = 30.0


class FacilitatorClient:
    """
    Synchronous facilitator client (good for scripts/tools).

    For FastAPI middleware, prefer AsyncFacilitatorClient to avoid blocking
    the event loop.
    """

    def __init__(
        self,
        options: FacilitatorClientOptions,
        *,
        headers: Optional[Mapping[str, str]] = None,
    ) -> None:
        self._options = options
        self._headers = dict(headers or {})

    @staticmethod
    def _decode_payment_header(payment_header: str) -> PaymentPayload:
        decoded = base64.b64decode(payment_header)
        envelope = json.loads(decoded)
        if not isinstance(envelope, dict):
            raise ValueError("Invalid PAYMENT-SIGNATURE header (decoded JSON was not an object)")
        payload = PaymentPayload.from_dict(envelope)
        if payload.x402_version != 2:
            raise ValueError("Invalid PAYMENT-SIGNATURE header (expected x402Version=2)")
        return payload

    def supported(self, *, x402_version: int = 2) -> FacilitatorSupportedResponse:  # noqa: ARG002
        """
        Calls GET /supported and returns supported (scheme, network) pairs.
        """
        url = self._options.base_url.rstrip("/") + "/supported"
        resp = httpx.get(url, headers=self._headers, timeout=self._options.timeout_seconds)
        _raise_for_status(resp)
        data = resp.json()
        return FacilitatorSupportedResponse.from_wire(data)

    def verify(
        self,
        *,
        payment_header: str,
        payment_requirements: PaymentRequirements,
        extensions: Mapping[str, Any] | None = None,
        x402_version: int = 2,  # noqa: ARG002
    ) -> PaymentVerifyResponse:
        """
        POST /verify using v2 `{ paymentPayload, paymentRequirements }`.

        `payment_header` is the base64 JSON value of the `PAYMENT-SIGNATURE` header.
        """
        url = self._options.base_url.rstrip("/") + "/verify"
        payment_payload = self._decode_payment_header(payment_header)
        body = {
            "paymentPayload": payment_payload.to_dict(),
            "paymentRequirements": payment_requirements.to_dict(),
        }
        if extensions is not None:
            body["extensions"] = dict(extensions)
        resp = httpx.post(
            url,
            json=body,
            headers=self._headers,
            timeout=self._options.timeout_seconds,
        )
        _raise_for_status(resp)
        return PaymentVerifyResponse.from_wire(resp.json())

    def settle(
        self,
        *,
        payment_header: str,
        payment_requirements: PaymentRequirements,
        extensions: Mapping[str, Any] | None = None,
        x402_version: int = 2,  # noqa: ARG002
    ) -> SettlementResponse:
        """
        POST /settle.
        """
        url = self._options.base_url.rstrip("/") + "/settle"
        payment_payload = self._decode_payment_header(payment_header)
        body = {
            "paymentPayload": payment_payload.to_dict(),
            "paymentRequirements": payment_requirements.to_dict(),
        }
        if extensions is not None:
            body["extensions"] = dict(extensions)
        resp = httpx.post(
            url,
            json=body,
            headers=self._headers,
            timeout=self._options.timeout_seconds,
        )
        _raise_for_status(resp)
        return SettlementResponse.from_wire(resp.json())

    def create_x402_secure_requirements(
        self,
        *,
        resource: Mapping[str, Any],
        payment_requirements: list[PaymentRequirements],
        merchant: Mapping[str, Any] | None = None,
        requested_policy_id: str | None = None,
    ) -> dict[str, Any]:
        url = self._options.base_url.rstrip("/") + "/verifiable-intent/requirements"
        body: dict[str, Any] = {
            "resource": dict(resource),
            "paymentRequirements": [req.to_dict() for req in payment_requirements],
        }
        if merchant is not None:
            body["merchant"] = dict(merchant)
        if requested_policy_id is not None:
            body["requestedPolicyId"] = requested_policy_id
        resp = httpx.post(
            url,
            json=body,
            headers=self._headers,
            timeout=self._options.timeout_seconds,
        )
        _raise_for_status(resp)
        data = resp.json()
        if not isinstance(data, dict):
            raise ValueError("invalid_x402_secure_requirements_response")
        return data


class AsyncFacilitatorClient:
    """
    Async facilitator client suitable for FastAPI/Starlette middleware.
    """

    def __init__(
        self,
        options: FacilitatorClientOptions,
        *,
        headers: Optional[Mapping[str, str]] = None,
    ) -> None:
        self._options = options
        self._headers = dict(headers or {})
        self._client = httpx.AsyncClient(
            base_url=options.base_url.rstrip("/"),
            headers=self._headers,
            timeout=options.timeout_seconds,
        )

    async def aclose(self) -> None:
        await self._client.aclose()

    async def supported(self, *, x402_version: int = 2) -> FacilitatorSupportedResponse:  # noqa: ARG002
        resp = await self._client.get("/supported")
        _raise_for_status(resp)
        return FacilitatorSupportedResponse.from_wire(resp.json())

    async def verify(
        self,
        *,
        payment_header: str,
        payment_requirements: PaymentRequirements,
        extensions: Mapping[str, Any] | None = None,
        x402_version: int = 2,  # noqa: ARG002
    ) -> PaymentVerifyResponse:
        payment_payload = FacilitatorClient._decode_payment_header(payment_header)
        shaped = {
            "paymentPayload": payment_payload.to_dict(),
            "paymentRequirements": payment_requirements.to_dict(),
        }
        if extensions is not None:
            shaped["extensions"] = dict(extensions)
        resp = await self._client.post("/verify", json=shaped)
        _raise_for_status(resp)
        return PaymentVerifyResponse.from_wire(resp.json())

    async def settle(
        self,
        *,
        payment_header: str,
        payment_requirements: PaymentRequirements,
        extensions: Mapping[str, Any] | None = None,
        x402_version: int = 2,  # noqa: ARG002
    ) -> SettlementResponse:
        payment_payload = FacilitatorClient._decode_payment_header(payment_header)
        shaped = {
            "paymentPayload": payment_payload.to_dict(),
            "paymentRequirements": payment_requirements.to_dict(),
        }
        if extensions is not None:
            shaped["extensions"] = dict(extensions)
        resp = await self._client.post("/settle", json=shaped)
        _raise_for_status(resp)
        return SettlementResponse.from_wire(resp.json())

    async def create_x402_secure_requirements(
        self,
        *,
        resource: Mapping[str, Any],
        payment_requirements: list[PaymentRequirements],
        merchant: Mapping[str, Any] | None = None,
        requested_policy_id: str | None = None,
    ) -> dict[str, Any]:
        body: dict[str, Any] = {
            "resource": dict(resource),
            "paymentRequirements": [req.to_dict() for req in payment_requirements],
        }
        if merchant is not None:
            body["merchant"] = dict(merchant)
        if requested_policy_id is not None:
            body["requestedPolicyId"] = requested_policy_id
        resp = await self._client.post("/verifiable-intent/requirements", json=body)
        _raise_for_status(resp)
        data = resp.json()
        if not isinstance(data, dict):
            raise ValueError("invalid_x402_secure_requirements_response")
        return data

