from __future__ import annotations

import asyncio
import base64
import inspect
import json
import logging
import uuid
from dataclasses import dataclass
from decimal import Decimal, InvalidOperation
from typing import Any, Awaitable, Callable, Mapping, Optional, Protocol, Sequence, Union

import httpx
from starlette.requests import Request
from starlette.responses import JSONResponse, Response

from x402_xrpl.facilitator import AsyncFacilitatorClient, FacilitatorClientOptions
from x402_xrpl.types import (
    PaymentPayload, PaymentRequired, PaymentRequirements, ResourceInfo,
    PaymentVerifyResponse, SettlementResponse,
)
from x402_xrpl.x402_secure import X402_SECURE_EXTENSION_KEY, x402_secure_extension

XRPLNetworkId = str

logger = logging.getLogger(__name__)


class InvoiceStore(Protocol):
    """
    Minimal persistence contract to bind an issued invoice to its PaymentRequirements.
    (Use Redis/DB in production; memory store is fine for dev.)
    """

    async def put(
        self,
        invoice_id: str,
        reqs: Sequence[PaymentRequirements],
        *,
        ttl_seconds: int,
    ) -> None: ...

    async def get(self, invoice_id: str) -> Optional[Sequence[PaymentRequirements]]: ...

    async def consume(self, invoice_id: str) -> None: ...


@dataclass(frozen=True)
class RequireX402PaymentOption:
    """
    One accepted payment option for an x402-protected resource.

    XRPL notes:
      - For IOUs (asset != "XRP"), issuer MUST be provided (or via extra["issuer"]).
      - max_amount_required is a string:
          - XRP: drops string
          - IOU: issued-currency "value" string
    """

    asset: str
    amount: str
    issuer: Optional[str] = None
    extra: Optional[Mapping[str, Any]] = None


class UsageMeter:
    """How a resource handler reports what it actually consumed.

    The `upto` scheme quotes a ceiling up front and charges the metered amount
    afterwards, so the handler is the only thing that knows the real cost. The
    middleware puts one of these on ``request.state.x402_upto_meter`` before
    running the handler and reads it after.

    A handler that never reports is treated as **zero**, not as the ceiling.
    Failing to report is a merchant bug, and charging every buyer the maximum
    because of it would be the worst possible reading of the scheme -- the cost
    of the bug belongs with the merchant.
    """

    __slots__ = ("_amount",)

    def __init__(self) -> None:
        self._amount: Optional[str] = None

    def report(self, amount: Union[str, int, float, Decimal]) -> None:
        """Report the metered cost, in the asset of the payment requirement."""
        value = str(amount)
        try:
            parsed = Decimal(value)
        except (InvalidOperation, ValueError) as exc:
            raise ValueError(f"metered amount is not a number: {amount!r}") from exc
        if parsed < 0:
            raise ValueError(f"metered amount must not be negative: {amount!r}")
        self._amount = value

    @property
    def reported(self) -> bool:
        return self._amount is not None

    @property
    def amount(self) -> str:
        return self._amount if self._amount is not None else "0"


# (signed CheckCreate blob, metered amount) -> signed CheckCash blob.
# Deliberately a callable rather than a wallet: the merchant decides whether that
# is a local key, a KMS signer or a multisign quorum, and the SDK never sees it.
UptoCashSigner = Callable[[str, str], Union[str, Awaitable[str]]]

UPTO_METER_ATTR = "x402_upto_meter"


@dataclass(frozen=True)
class RequireX402Options:
    # required pricing fields (x402 PaymentRequirements)
    pay_to: str
    amount: str  # XRP: drops string; IOUs: XRPL issued-currency "value" string
    scheme: str = "exact"
    network: XRPLNetworkId = "xrpl:1"
    asset: str = "XRP"
    issuer: Optional[str] = None  # required for XRPL IOU assets (non-XRP)
    max_timeout_seconds: int = 600

    # resource metadata (recommended by spec)
    resource: Optional[str] = None  # default: request.url
    description: str = ""
    mime_type: str = "application/json"
    output_schema: Optional[dict[str, Any]] = None
    extra: Optional[Mapping[str, Any]] = None
    payment_options: Optional[Sequence[RequireX402PaymentOption]] = None

    # facilitator self-identity (declared in the 402 challenge extra.facilitator).
    # When set, an object {"id": ..., "name": ...} is injected per-option unless the
    # option already carries its own extra["facilitator"]. None => no injection (legacy).
    facilitator_identity: Optional[Mapping[str, Any]] = None

    # XRPL analytics SourceTag (a per-deployment, registered tag; NOT a shared
    # protocol value). When set, extra["sourceTag"] is injected per-option unless
    # the option already carries its own sourceTag. None => no injection (and the
    # facilitator does not enforce a SourceTag for these requirements).
    source_tag: Optional[int] = None

    # `upto` only: signs the merchant's CheckCash for the metered amount, after
    # the handler has run. Required when scheme == "upto" and settle is enabled.
    upto_sign_check_cash: Optional[UptoCashSigner] = None

    # where to settle/verify
    facilitator: Optional[AsyncFacilitatorClient] = None
    facilitator_url: Optional[str] = None  # convenience constructor
    facilitator_headers: Optional[Mapping[str, str]] = None

    # routing
    path: Optional[str | Sequence[str]] = None  # protect all if None

    # invoice binding
    invoice_store: Optional[InvoiceStore] = None
    invoice_ttl_seconds: int = 900
    invoice_id_factory: Optional[Callable[[], str]] = None

    # settlement strategy
    settle: bool = True  # verify only if False (still spec-compatible)

    # X402 Secure / Verifiable Intent route metadata
    x402_secure_policy_id: Optional[str] = None
    merchant_id: Optional[str] = None
    origin: Optional[str] = None
    route_id: Optional[str] = None


class _InMemoryInvoiceStore:
    def __init__(self) -> None:
        self._data: dict[str, Sequence[PaymentRequirements]] = {}

    async def put(
        self,
        invoice_id: str,
        reqs: Sequence[PaymentRequirements],
        *,
        ttl_seconds: int,  # noqa: ARG002
    ) -> None:
        self._data[invoice_id] = reqs

    async def get(self, invoice_id: str) -> Optional[Sequence[PaymentRequirements]]:
        return self._data.get(invoice_id)

    async def consume(self, invoice_id: str) -> None:
        self._data.pop(invoice_id, None)


def _normalize_paths(path: Optional[str | Sequence[str]]) -> Optional[set[str]]:
    if path is None:
        return None
    if isinstance(path, str):
        return {path}
    return set(path)


def _payment_required_header(body: Mapping[str, Any]) -> str:
    return base64.b64encode(json.dumps(body, separators=(",", ":"), sort_keys=True).encode("utf-8")).decode("utf-8")


def _retry_after_seconds(value: Any) -> int:
    try:
        return max(0, int(value))
    except (TypeError, ValueError):
        return 30


def _correlation_id(
    request: Request,
    *,
    headers: Mapping[str, Any] | None = None,
    body: Mapping[str, Any] | None = None,
) -> str:
    return str(
        (headers or {}).get("X-Correlation-ID")
        or (body or {}).get("correlationId")
        or request.headers.get("X-Correlation-ID")
        or uuid.uuid4()
    )


def _verify_transient_response(
    request: Request,
    *,
    upstream_status: int,
    body: Any = None,
    headers: Mapping[str, Any] | None = None,
    reason: str | None = None,
) -> JSONResponse | None:
    if upstream_status not in {408, 429} and upstream_status < 500:
        return None

    outer_body = body if isinstance(body, Mapping) else {}
    transient = outer_body
    detail = outer_body.get("detail")
    if isinstance(detail, Mapping):
        transient = detail

    # A verify response that claims settlement may have started is internally
    # inconsistent. Fail closed and do not advertise it as safely retryable.
    if transient.get("settlementAttempted") is True or transient.get("phase") == "settle":
        return None

    is_typed = (
        transient.get("retryable") is True
        and transient.get("phase", "verify") == "verify"
        and transient.get("settlementAttempted", False) is False
    )
    transient_reason = (
        str(transient.get("reason") or "facilitator_unavailable")
        if is_typed
        else reason or "facilitator_unavailable"
    )
    retry_after = _retry_after_seconds(
        (headers or {}).get("Retry-After")
        or transient.get("retryAfter")
        or outer_body.get("retryAfter")
        or 30
    )
    correlation_body = dict(transient)
    if outer_body.get("correlationId"):
        correlation_body["correlationId"] = outer_body["correlationId"]
    correlation_id = _correlation_id(request, headers=headers, body=correlation_body)
    response_headers = {
        "Retry-After": str(retry_after),
        "X-Correlation-ID": correlation_id,
    }
    logger.warning(
        "facilitator verify transient",
        extra={
            "correlation_id": correlation_id,
            "phase": "verify",
            "reason": transient_reason,
            "retry_after": retry_after,
            "retryable": True,
            "settlement_attempted": False,
            "upstream_status": upstream_status,
        },
    )
    return JSONResponse(
        status_code=503,
        content={
            "error": transient_reason,
            "reason": transient_reason,
            "retryable": True,
            "retryAfter": retry_after,
            "correlationId": correlation_id,
            "phase": "verify",
            "settlementAttempted": False,
        },
        headers=response_headers,
    )


def _verify_permanent_http_response(
    request: Request,
    *,
    upstream_status: int,
    body: Any,
    headers: Mapping[str, Any] | None = None,
) -> JSONResponse:
    outer_body = body if isinstance(body, Mapping) else {}
    detail = outer_body.get("detail")
    reason = (
        detail
        if isinstance(detail, str) and detail
        else outer_body.get("reason")
        or outer_body.get("error")
        or f"verify_http_error:{upstream_status}"
    )
    correlation_id = _correlation_id(request, headers=headers, body=outer_body)
    logger.warning(
        "facilitator verify permanent failure",
        extra={
            "correlation_id": correlation_id,
            "phase": "verify",
            "reason": str(reason),
            "retryable": False,
            "settlement_attempted": False,
            "upstream_status": upstream_status,
        },
    )
    return JSONResponse(
        status_code=upstream_status,
        content={
            "error": str(reason),
            "reason": str(reason),
            "retryable": False,
            "correlationId": correlation_id,
            "phase": "verify",
            "settlementAttempted": False,
        },
        headers={"X-Correlation-ID": correlation_id},
    )


def _policy_deny_response(request: Request, *, reason: str) -> JSONResponse:
    correlation_id = _correlation_id(request)
    logger.warning(
        "facilitator policy denied payment",
        extra={
            "correlation_id": correlation_id,
            "phase": "verify",
            "reason": reason,
            "retryable": False,
            "settlement_attempted": False,
        },
    )
    return JSONResponse(
        status_code=403,
        content={
            "error": reason,
            "reason": reason,
            "retryable": False,
            "correlationId": correlation_id,
            "phase": "verify",
            "settlementAttempted": False,
        },
        headers={"X-Correlation-ID": correlation_id},
    )


def _legacy_settlement_status_unknown(reason: Any) -> bool:
    return isinstance(reason, str) and reason.startswith(
        ("submit_failed:", "submit_missing_tx_hash", "validation_failed:")
    )


def _settlement_status_unknown_response(
    *,
    correlation_id: str = "",
) -> JSONResponse:
    headers = {"X-Correlation-ID": correlation_id} if correlation_id else {}
    return JSONResponse(
        status_code=409,
        content={
            "error": "settlement_status_unknown",
            "reason": "settlement_status_unknown",
            "retryable": False,
            "correlationId": correlation_id,
            "phase": "settle",
            "settlementAttempted": True,
        },
        headers=headers,
    )


async def _maybe_x402_secure_extensions(
    *,
    options: RequireX402Options,
    facilitator: Any,
    resource_url: str,
    reqs: Sequence[PaymentRequirements],
) -> dict[str, Any]:
    if not options.x402_secure_policy_id:
        return {}
    if len(reqs) != 1:
        raise ValueError("x402_secure_requires_single_payment_requirement")
    merchant: dict[str, Any] = {}
    if options.merchant_id is not None:
        merchant["merchantId"] = options.merchant_id
    if options.origin is not None:
        merchant["origin"] = options.origin
    if options.route_id is not None:
        merchant["routeId"] = options.route_id

    create = getattr(facilitator, "create_x402_secure_requirements", None)
    if create is not None:
        result = create(
            resource={
                "url": resource_url,
                "description": options.description,
                "mimeType": options.mime_type,
            },
            payment_requirements=list(reqs),
            merchant=merchant,
            requested_policy_id=options.x402_secure_policy_id,
        )
        if inspect.isawaitable(result):
            result = await result
    else:
        resp = await facilitator._client.post(  # type: ignore[attr-defined]
            "/verifiable-intent/requirements",
            json={
                "resource": {
                    "url": resource_url,
                    "description": options.description,
                    "mimeType": options.mime_type,
                },
                "paymentRequirements": [req.to_dict() for req in reqs],
                "merchant": merchant,
                "requestedPolicyId": options.x402_secure_policy_id,
            },
        )
        if resp.status_code != 200:
            raise ValueError(f"x402_secure_requirements_http_error:{resp.status_code}")
        result = resp.json()

    if not isinstance(result, Mapping):
        raise ValueError("invalid_x402_secure_requirements_response")
    secure = x402_secure_extension(result)
    if not secure:
        raise ValueError("missing_x402_secure_requirements_envelope")
    return {X402_SECURE_EXTENSION_KEY: secure}


async def _build_payment_required_body(
    *,
    options: RequireX402Options,
    facilitator: Any,
    request: Request,
    reqs: Sequence[PaymentRequirements],
    error: str,
) -> dict[str, Any]:
    resource_url = options.resource or str(request.url)
    extensions = await _maybe_x402_secure_extensions(
        options=options,
        facilitator=facilitator,
        resource_url=resource_url,
        reqs=reqs,
    )
    return PaymentRequired(
        x402_version=2,
        error=error,
        resource=ResourceInfo(url=resource_url, description=options.description, mime_type=options.mime_type),
        accepts=reqs,
        extensions=extensions,
    ).to_dict()


def _requirements_failure_response(exc: Exception) -> JSONResponse:
    logger.warning("X402 Secure requirements creation failed: %s", exc)
    return JSONResponse(
        status_code=502,
        content={
            "error": "x402_secure_requirements_unavailable",
        },
    )


def _decision_token_from_verify_response(verify_json: Mapping[str, Any]) -> str | None:
    secure = x402_secure_extension(verify_json.get("extensions") if isinstance(verify_json.get("extensions"), Mapping) else None)
    token = secure.get("decisionToken")
    return token if isinstance(token, str) and token else None


@dataclass(frozen=True)
class _UptoSettlement:
    success: bool
    header: Optional[str] = None
    error: Optional[str] = None


async def _settle_upto(
    *,
    request: Request,
    options: "RequireX402Options",
    facilitator: Any,
    payment_payload: Any,
    selected_req: Any,
    amount: str,
    verify_json: Mapping[str, Any],
) -> _UptoSettlement:
    """Sign the merchant's CheckCash for the metered amount and settle it.

    `accepted` keeps the ceiling the payer signed; only paymentRequirements.amount
    carries the metered amount, per the scheme's phase-dependent semantics.
    """
    payload_dict = payment_payload.to_dict()
    scheme_payload = dict(payload_dict.get("payload") or {})
    create_blob = scheme_payload.get("signedCheckCreateBlob")
    if not isinstance(create_blob, str) or not create_blob:
        return _UptoSettlement(False, error="missing_signed_check_create_blob")

    if Decimal(amount) > 0:
        assert options.upto_sign_check_cash is not None
        try:
            # A sync signer almost always does blocking network I/O (xrpl-py's
            # sync helpers even spin their own event loop internally, which raises
            # if called from a running one). Run it off the loop rather than
            # inline: without this, the SDK's own merchant helper cannot be used
            # from the async middleware at all.
            signer = options.upto_sign_check_cash
            if inspect.iscoroutinefunction(signer):
                signed = await signer(create_blob, amount)
            else:
                # Decided by function type, never by calling it twice: this signs.
                signed = await asyncio.to_thread(signer, create_blob, amount)
                if inspect.isawaitable(signed):
                    signed = await signed
        except Exception as exc:  # merchant-side signing failure
            return _UptoSettlement(False, error=f"check_cash_signing_failed:{exc}")
        if not isinstance(signed, str) or not signed:
            return _UptoSettlement(False, error="check_cash_signer_returned_nothing")
        scheme_payload["signedCheckCashBlob"] = signed

    payload_dict["payload"] = scheme_payload
    requirements = selected_req.to_dict()
    requirements["amount"] = amount

    settle_body: dict[str, Any] = {
        "paymentPayload": payload_dict,
        "paymentRequirements": requirements,
    }
    decision_token = _decision_token_from_verify_response(verify_json)
    if decision_token:
        settle_body["extensions"] = {X402_SECURE_EXTENSION_KEY: {"decisionToken": decision_token}}

    try:
        resp = await facilitator._client.post("/settle", json=settle_body)  # type: ignore[attr-defined]
    except httpx.RequestError as exc:
        return _UptoSettlement(False, error=f"settle_request_error:{exc}")

    if resp.status_code != 200:
        return _UptoSettlement(False, error=f"settle_http_error:{resp.status_code}")

    try:
        body = resp.json()
        SettlementResponse.from_wire(body)
    except (TypeError, ValueError):
        return _UptoSettlement(False, error="settlement_status_unknown")
    header = resp.headers.get("PAYMENT-RESPONSE") or (
        _payment_required_header(body) if body.get("success") else None
    )
    if not body.get("success"):
        return _UptoSettlement(False, header=header, error=str(body.get("errorReason")))
    return _UptoSettlement(True, header=header)


def require_x402(
    options: RequireX402Options,
) -> Callable[[Request, Callable[[Request], Awaitable[Response]]], Awaitable[Response]]:
    """
    FastAPI/Starlette middleware implementing the x402 flow:
      - If no PAYMENT-SIGNATURE: returns 402 Payment Required with v2 PaymentRequired body.
      - If PAYMENT-SIGNATURE present: calls facilitator /verify (and /settle if enabled) using
        v2 `{ paymentPayload, paymentRequirements }` body.
      - On success: forwards request to handler and sets PAYMENT-RESPONSE header
        containing base64-encoded Settlement Response JSON.
    """

    protected_paths = _normalize_paths(options.path)
    invoice_store: InvoiceStore = options.invoice_store or _InMemoryInvoiceStore()

    if options.facilitator is not None:
        facilitator = options.facilitator
    elif options.facilitator_url is not None:
        facilitator = AsyncFacilitatorClient(
            FacilitatorClientOptions(
                base_url=options.facilitator_url,
            ),
            headers=options.facilitator_headers,
        )
    else:
        raise ValueError("RequireX402Options.facilitator or facilitator_url must be provided")

    async def middleware(request: Request, call_next: Callable[[Request], Awaitable[Response]]) -> Response:
        # Pass through CORS preflight requests so CORSMiddleware can handle them
        if request.method == "OPTIONS":
            return await call_next(request)
        if protected_paths is not None and request.url.path not in protected_paths:
            return await call_next(request)

        payment_signature = request.headers.get("PAYMENT-SIGNATURE")
        if not payment_signature:
            invoice_id = options.invoice_id_factory() if options.invoice_id_factory else uuid.uuid4().hex.upper()

            option_specs = options.payment_options
            if not option_specs:
                option_specs = [
                    RequireX402PaymentOption(
                        asset=options.asset,
                        amount=options.amount,
                        issuer=options.issuer,
                        extra=options.extra,
                    )
                ]

            reqs: list[PaymentRequirements] = []
            for opt in option_specs:
                extra: dict[str, Any] | None = dict(options.extra) if options.extra else None
                if opt.extra:
                    extra = dict(extra or {})
                    extra.update(opt.extra)

                issuer = opt.issuer or options.issuer
                if issuer:
                    extra = dict(extra or {})
                    extra["issuer"] = issuer

                # v2: invoice id is carried in extra (and echoed in the scheme payload).
                extra = dict(extra or {})
                # XRPL analytics tag (payer-side, must be set before signing). Only
                # injected when a SourceTag is configured for this deployment and the
                # option does not already carry one. None => omit entirely (no default).
                if options.source_tag is not None and extra.get("sourceTag") is None:
                    extra["sourceTag"] = options.source_tag
                # Facilitator self-identity declaration (zero-config; only when configured
                # and not already supplied by the option's own extra). Backward compatible.
                if options.facilitator_identity is not None and extra.get("facilitator") is None:
                    extra["facilitator"] = dict(options.facilitator_identity)
                extra["invoiceId"] = invoice_id

                reqs.append(
                    PaymentRequirements(
                        scheme=options.scheme,
                        network=options.network,
                        amount=opt.amount,
                        asset=opt.asset,
                        pay_to=options.pay_to,
                        max_timeout_seconds=options.max_timeout_seconds,
                        extra=extra,
                    )
                )

            await invoice_store.put(invoice_id, reqs, ttl_seconds=options.invoice_ttl_seconds)

            try:
                body = await _build_payment_required_body(
                    options=options,
                    facilitator=facilitator,
                    request=request,
                    reqs=reqs,
                    error="PAYMENT-SIGNATURE header is required",
                )
            except Exception as exc:
                return _requirements_failure_response(exc)
            resp = JSONResponse(status_code=402, content=body)
            resp.headers["PAYMENT-REQUIRED"] = _payment_required_header(body)
            return resp

        # Decode envelope so we can recover invoice_id for lookup
        try:
            decoded_raw = json.loads(base64.b64decode(payment_signature))
        except Exception as exc:  # pragma: no cover - defensive
            return JSONResponse(
                status_code=400,
                content={"error": f"invalid_payment_signature_header:{exc}"},
            )

        if not isinstance(decoded_raw, dict):
            return JSONResponse(status_code=400, content={"error": "invalid_payment_signature_header"})

        try:
            payment_payload = PaymentPayload.from_dict(decoded_raw)
        except Exception as exc:  # pragma: no cover - defensive
            return JSONResponse(status_code=400, content={"error": f"invalid_payment_payload:{exc}"})

        if payment_payload.x402_version != 2:
            return JSONResponse(status_code=400, content={"error": "invalid_x402_version"})

        invoice_id = payment_payload.payload.get("invoiceId") if isinstance(payment_payload.payload, dict) else None
        if not invoice_id:
            return JSONResponse(status_code=400, content={"error": "missing_invoiceId"})

        stored = await invoice_store.get(invoice_id)
        if not stored:
            return JSONResponse(status_code=400, content={"error": "unknown_invoice_id"})

        stored_reqs = list(stored)
        selected_req: PaymentRequirements | None = None
        accepted = payment_payload.accepted
        for req in stored_reqs:
            if (
                req.scheme == accepted.scheme
                and req.network == accepted.network
                and req.amount == accepted.amount
                and req.asset == accepted.asset
                and req.pay_to == accepted.pay_to
                and req.max_timeout_seconds == accepted.max_timeout_seconds
                and req.invoice_id() == accepted.invoice_id()
            ):
                selected_req = req
                break

        if not selected_req:
            return JSONResponse(status_code=402, content={"error": "payment_requirements_mismatch"})

        if options.x402_secure_policy_id and not x402_secure_extension(payment_payload.extensions):
            try:
                body = await _build_payment_required_body(
                    options=options,
                    facilitator=facilitator,
                    request=request,
                    reqs=stored_reqs,
                    error="x402_secure_extension_required",
                )
            except Exception as exc:
                return _requirements_failure_response(exc)
            resp = JSONResponse(status_code=402, content=body)
            resp.headers["PAYMENT-REQUIRED"] = _payment_required_header(body)
            return resp

        verify_body = {
            "paymentPayload": payment_payload.to_dict(),
            "paymentRequirements": selected_req.to_dict(),
        }
        try:
            verify_resp = await facilitator._client.post("/verify", json=verify_body)  # type: ignore[attr-defined]
        except httpx.RequestError as exc:
            transient_response = _verify_transient_response(
                request,
                upstream_status=504 if isinstance(exc, httpx.TimeoutException) else 503,
                reason=(
                    "facilitator_timeout"
                    if isinstance(exc, httpx.TimeoutException)
                    else "facilitator_unavailable"
                ),
            )
            assert transient_response is not None
            return transient_response
        if verify_resp.status_code != 200:
            try:
                transient = verify_resp.json()
            except Exception:
                transient = {}
            typed_transient = _verify_transient_response(
                request,
                upstream_status=verify_resp.status_code,
                body=transient,
                headers=verify_resp.headers,
            )
            if typed_transient is not None:
                return typed_transient
            return _verify_permanent_http_response(
                request,
                upstream_status=verify_resp.status_code,
                body=transient,
                headers=verify_resp.headers,
            )
        try:
            verify_json = verify_resp.json()
            PaymentVerifyResponse.from_wire(verify_json)
        except (TypeError, ValueError):
            return JSONResponse(status_code=502, content={
                "error": "invalid_verify_response", "retryable": False,
                "phase": "verify", "settlementAttempted": False,
            })
        if not verify_json.get("isValid"):
            invalid_reason = str(verify_json.get("invalidReason") or "verify_failed")
            if invalid_reason == "verifiable_intent_denied":
                return _policy_deny_response(request, reason=invalid_reason)
            # Re-issue PaymentRequired so clients can retry with a new payment.
            try:
                body = await _build_payment_required_body(
                    options=options,
                    facilitator=facilitator,
                    request=request,
                    reqs=stored_reqs,
                    error=f"verify_failed:{invalid_reason}",
                )
            except Exception as exc:
                return _requirements_failure_response(exc)
            resp = JSONResponse(status_code=402, content=body)
            resp.headers["PAYMENT-REQUIRED"] = _payment_required_header(body)
            return resp

        if options.settle and selected_req.scheme == "upto":
            # `upto` inverts the ordering: the price is not knowable until the work
            # is done, so the handler runs first and settlement follows. Settling
            # before execution -- correct for `exact` -- would charge every buyer
            # the ceiling, which is the opposite of what the scheme is for.
            if options.upto_sign_check_cash is None:
                logger.error("upto requires options.upto_sign_check_cash to settle")
                return _requirements_failure_response(
                    RuntimeError("upto_sign_check_cash_not_configured")
                )

            meter = UsageMeter()
            setattr(request.state, UPTO_METER_ATTR, meter)
            inner_response = await call_next(request)

            if not meter.reported:
                logger.error(
                    "upto handler did not report usage; settling zero. "
                    "Call request.state.%s.report(amount) in the handler.",
                    UPTO_METER_ATTR,
                )

            # The ceiling is a cap, so honour it here rather than letting the
            # facilitator reject and leave already-delivered work unpaid. The buyer
            # can never be charged above what they authorized either way; clamping
            # just recovers the maximum they did authorize.
            amount = meter.amount
            if Decimal(amount) > Decimal(selected_req.amount):
                logger.error(
                    "upto: metered %s exceeds the quoted ceiling %s; charging the "
                    "ceiling. The quote is under-priced for this workload.",
                    amount,
                    selected_req.amount,
                )
                amount = str(selected_req.amount)

            settled = await _settle_upto(
                request=request,
                options=options,
                facilitator=facilitator,
                payment_payload=payment_payload,
                selected_req=selected_req,
                amount=amount,
                verify_json=verify_json,
            )
            await invoice_store.consume(invoice_id)

            if settled.header:
                inner_response.headers["PAYMENT-RESPONSE"] = settled.header
            if not settled.success:
                # The work is already delivered -- withholding the response now
                # would punish the buyer for a settlement problem they cannot fix.
                # Surface it for merchant-side reconciliation instead.
                logger.error("upto settlement failed after delivery: %s", settled.error)
                inner_response.headers["X-402-Settlement-Error"] = str(settled.error or "unknown")
            return inner_response

        if options.settle:
            decision_token = _decision_token_from_verify_response(verify_json)
            settle_body = {
                "paymentPayload": payment_payload.to_dict(),
                "paymentRequirements": selected_req.to_dict(),
            }
            if decision_token:
                settle_body["extensions"] = {X402_SECURE_EXTENSION_KEY: {"decisionToken": decision_token}}
            try:
                settle_resp = await facilitator._client.post("/settle", json=settle_body)  # type: ignore[attr-defined]
            except httpx.RequestError:
                correlation_id = _correlation_id(request)
                logger.error(
                    "facilitator settlement status unknown",
                    extra={
                        "correlation_id": correlation_id,
                        "phase": "settle",
                        "retryable": False,
                        "settlement_attempted": True,
                    },
                )
                return _settlement_status_unknown_response(correlation_id=correlation_id)
            if settle_resp.status_code != 200:
                try:
                    settle_error = settle_resp.json()
                except Exception:
                    settle_error = {}
                if (
                    isinstance(settle_error, dict)
                    and settle_error.get("settlementAttempted") is True
                ):
                    return _settlement_status_unknown_response(
                        correlation_id=str(
                            settle_resp.headers.get("X-Correlation-ID")
                            or settle_error.get("correlationId")
                            or ""
                        )
                    )
                return JSONResponse(
                    status_code=502,
                    content={
                        "error": f"settle_http_error:{settle_resp.status_code}",
                        "reason": "settlement_status_unknown",
                        "retryable": False,
                        "phase": "settle",
                        "settlementAttempted": True,
                    },
                )
            try:
                settle_json = settle_resp.json()
                SettlementResponse.from_wire(settle_json)
            except (TypeError, ValueError):
                return _settlement_status_unknown_response(correlation_id=_correlation_id(request))
            if not settle_json.get("success"):
                if _legacy_settlement_status_unknown(settle_json.get("errorReason")):
                    return _settlement_status_unknown_response()
                try:
                    body = await _build_payment_required_body(
                        options=options,
                        facilitator=facilitator,
                        request=request,
                        reqs=stored_reqs,
                        error=f"settle_failed:{settle_json.get('errorReason')}",
                    )
                except Exception as exc:
                    return _requirements_failure_response(exc)
                resp = JSONResponse(status_code=402, content=body)
                resp.headers["PAYMENT-REQUIRED"] = _payment_required_header(body)
                return resp

            await invoice_store.consume(invoice_id)

            inner_response = await call_next(request)
            if "PAYMENT-RESPONSE" in settle_resp.headers:
                inner_response.headers["PAYMENT-RESPONSE"] = settle_resp.headers["PAYMENT-RESPONSE"]
            elif settle_json.get("success"):
                inner_response.headers["PAYMENT-RESPONSE"] = _payment_required_header(settle_json)
            return inner_response

        # verify-only mode: forward on success without calling /settle
        return await call_next(request)

    return middleware


def require_payment(
    *,
    path: Optional[str | Sequence[str]] = None,
    price: str | int,
    pay_to_address: str,
    network: XRPLNetworkId = "xrpl:1",
    facilitator_url: str | None = None,
    facilitator: AsyncFacilitatorClient | None = None,
    facilitator_headers: Mapping[str, str] | None = None,
    asset: str = "XRP",
    issuer: str | None = None,
    scheme: str = "exact",
    max_timeout_seconds: int = 600,
    resource: str | None = None,
    description: str = "",
    mime_type: str = "application/json",
    output_schema: Mapping[str, Any] | None = None,
    extra: Mapping[str, Any] | None = None,
    payment_options: Sequence[RequireX402PaymentOption] | None = None,
    facilitator_identity: Mapping[str, Any] | None = None,
    source_tag: int | None = None,
    invoice_store: InvoiceStore | None = None,
    invoice_ttl_seconds: int = 900,
    invoice_id_factory: Callable[[], str] | None = None,
    settle: bool = True,
    x402_secure_policy_id: str | None = None,
    merchant_id: str | None = None,
    origin: str | None = None,
    route_id: str | None = None,
) -> Callable[[Request, Callable[[Request], Awaitable[Response]]], Awaitable[Response]]:
    """
    Ergonomic wrapper around require_x402(...) using XRPL-style inputs.

    Notes:
      - `path` is currently exact-match only (no wildcards/globs).
      - `price` is:
          - XRP: drops string/int (1 XRP = 1_000_000 drops)
          - IOU: issued-currency value string (e.g. "1", "1.25")
      - For IOUs (asset != "XRP"), `issuer` must be provided (or via extra["issuer"]).
    """
    options = RequireX402Options(
        pay_to=pay_to_address,
        amount=str(price),
        scheme=scheme,
        network=network,
        asset=asset,
        issuer=issuer,
        max_timeout_seconds=max_timeout_seconds,
        resource=resource,
        description=description,
        mime_type=mime_type,
        output_schema=dict(output_schema) if output_schema is not None else None,
        extra=extra,
        payment_options=payment_options,
        facilitator_identity=dict(facilitator_identity) if facilitator_identity is not None else None,
        source_tag=source_tag,
        facilitator=facilitator,
        facilitator_url=facilitator_url,
        facilitator_headers=facilitator_headers,
        path=path,
        invoice_store=invoice_store,
        invoice_ttl_seconds=invoice_ttl_seconds,
        invoice_id_factory=invoice_id_factory,
        settle=settle,
        x402_secure_policy_id=x402_secure_policy_id,
        merchant_id=merchant_id,
        origin=origin,
        route_id=route_id,
    )
    return require_x402(options)
