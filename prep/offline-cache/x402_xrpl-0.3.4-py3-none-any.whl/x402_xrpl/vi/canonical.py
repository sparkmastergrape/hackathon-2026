from __future__ import annotations

import hashlib
import json
from collections.abc import Mapping
from typing import Any


def _as_mapping(payment_requirements: Any) -> Mapping[str, Any]:
    if isinstance(payment_requirements, Mapping):
        return payment_requirements
    to_dict = getattr(payment_requirements, "to_dict", None)
    if callable(to_dict):
        value = to_dict()
        if isinstance(value, Mapping):
            return value
    raise ValueError("invalid_payment_requirements")


def _invoice_id(payment_requirements: Mapping[str, Any]) -> str:
    extra = payment_requirements.get("extra")
    if not isinstance(extra, Mapping):
        raise ValueError("payment_requirements_invoice_id_required")
    invoice_id = extra.get("invoiceId") or extra.get("invoice_id")
    if not isinstance(invoice_id, str) or not invoice_id.strip():
        raise ValueError("payment_requirements_invoice_id_required")
    return invoice_id


def canonical_payment_requirements_json(payment_requirements: Any) -> str:
    wire = _as_mapping(payment_requirements)
    _invoice_id(wire)
    return json.dumps(wire, sort_keys=True, separators=(",", ":"), ensure_ascii=False)


def payment_requirements_hash(payment_requirements: Any) -> str:
    canonical = canonical_payment_requirements_json(payment_requirements)
    digest = hashlib.sha256(canonical.encode("utf-8")).hexdigest()
    return f"sha256:{digest}"
