from __future__ import annotations

import base64
import hashlib
import inspect
import json
import os
import time
import urllib.error
import urllib.request
import uuid
from collections.abc import Callable, Mapping
from dataclasses import dataclass
from typing import Any

from cryptography.hazmat.primitives import hashes
from cryptography.hazmat.primitives.asymmetric import ec, utils

from .canonical import payment_requirements_hash

TRUSTLINE_VI_AUDIENCE = 'trustline-vi'
TRUSTLINE_VI_L2_VCT = 'mandate.payment.open.1'

JWK = Mapping[str, Any]
ChainNode = Mapping[str, Any] | str


@dataclass(frozen=True)
class LocalProducerDelegation:
    l1_credential: ChainNode
    l2_delegation: ChainNode
    agent_private_jwk: JWK
    agent_kid: str
    issuer_kid: str | None = None


class LocalProducerProvider:
    def __init__(
        self,
        *,
        delegation: LocalProducerDelegation
        | Mapping[str, Any]
        | Callable[[Mapping[str, Any]], LocalProducerDelegation | Mapping[str, Any] | None]
        | None,
        audience: str = TRUSTLINE_VI_AUDIENCE,
        now: Callable[[], int] | None = None,
        ttl_seconds: int = 300,
        issuer: str | None = None,
        idempotency_key: str | Callable[[Mapping[str, Any]], str | None] | None = None,
        include_readable_transaction_fields: bool = False,
    ) -> None:
        self._delegation = delegation
        self._audience = audience
        self._now = now
        self._ttl_seconds = ttl_seconds
        self._issuer = issuer
        self._idempotency_key = idempotency_key
        self._include_readable_transaction_fields = include_readable_transaction_fields

    def prepare_evidence(self, input_data: Mapping[str, Any]) -> Mapping[str, Any]:
        delegation = self._resolve_delegation(input_data)
        if delegation is None:
            return {
                'status': 'requires_confirmation',
                'reason': 'verifiable_intent_delegation_required',
                'confirmationRequest': {'x402Secure': input_data.get('x402Secure')},
            }

        payment_requirements = input_data.get('selectedPaymentRequirements')
        invoice_id = _invoice_id_from_payment_requirements(payment_requirements)
        req_hash = payment_requirements_hash(payment_requirements)
        l2_node = normalize_chain_node(_delegation_get(delegation, 'l2_delegation'), 'kb-sd-jwt+kb')
        l2_presentation = chain_node_presentation(l2_node)
        idempotency_key = self._resolve_idempotency_key(input_data) or invoice_id
        agent_private_jwk = _delegation_get(delegation, 'agent_private_jwk')
        if not isinstance(agent_private_jwk, Mapping):
            raise ValueError('agent_private_jwk_required')
        agent_kid = _delegation_get(delegation, 'agent_kid')
        if not isinstance(agent_kid, str) or not agent_kid.strip():
            raise ValueError('agent_kid_required')

        l3 = sign_l3_final_action(
            agent_private_jwk=agent_private_jwk,
            agent_kid=agent_kid.strip(),
            l2_presentation=l2_presentation,
            transaction={
                'paymentRequirementsHash': req_hash,
                'invoiceId': invoice_id,
                **(
                    _readable_transaction_fields(payment_requirements, input_data)
                    if self._include_readable_transaction_fields
                    else {}
                ),
            },
            idempotency_key=idempotency_key,
            audience=self._audience,
            issuer=self._issuer,
            now=self._now() if self._now else None,
            ttl_seconds=self._ttl_seconds,
        )

        return {
            'status': 'ready',
            'x402SecurePatch': {
                'verifiableIntentChain': build_verifiable_intent_chain(
                    l1_credential=_delegation_get(delegation, 'l1_credential'),
                    l2_delegation=l2_node,
                    l3_final_action=l3,
                    issuer_kid=_optional_text(_delegation_get_optional(delegation, 'issuer_kid')),
                )
            },
        }

    def _resolve_delegation(
        self,
        input_data: Mapping[str, Any],
    ) -> LocalProducerDelegation | Mapping[str, Any] | None:
        if not callable(self._delegation):
            return self._delegation
        value = self._delegation(input_data)
        if inspect.isawaitable(value):
            raise ValueError('local_producer_delegation_must_be_sync')
        return value

    def _resolve_idempotency_key(self, input_data: Mapping[str, Any]) -> str | None:
        if callable(self._idempotency_key):
            return self._idempotency_key(input_data)
        return self._idempotency_key


class RemoteIssuerSource:
    def __init__(
        self,
        *,
        endpoint: str,
        headers: Mapping[str, str] | Callable[[], Mapping[str, str]] | None = None,
        post_json: Callable[[str, Mapping[str, Any], Mapping[str, str]], Mapping[str, Any]] | None = None,
    ) -> None:
        self._endpoint = endpoint
        self._headers = headers
        self._post_json = post_json or _default_post_json

    def issue_l1(self, request: Mapping[str, Any]) -> ChainNode:
        endpoint = _require_text(self._endpoint, 'remote_issuer_endpoint')
        response = self._post_json(endpoint, dict(request), self._resolve_headers())
        return _l1_credential_from_response(response)

    def _resolve_headers(self) -> Mapping[str, str]:
        headers = self._headers() if callable(self._headers) else self._headers
        if not headers:
            return {}
        return {
            str(key): value
            for key, value in headers.items()
            if isinstance(value, str) and str(key).strip()
        }


class RemoteIssuerProvider:
    def __init__(
        self,
        *,
        issuer: RemoteIssuerSource
        | Callable[[Mapping[str, Any], Mapping[str, Any]], ChainNode | Mapping[str, Any]],
        issue_request: Mapping[str, Any] | Callable[[Mapping[str, Any]], Mapping[str, Any]],
        owner_private_jwk: JWK,
        agent_private_jwk: JWK,
        owner_kid: str | None = None,
        agent_public_jwk: JWK | None = None,
        agent_kid: str | None = None,
        constraints: Mapping[str, Any] | Callable[[Mapping[str, Any]], Mapping[str, Any]] | None = None,
        audience: str = TRUSTLINE_VI_AUDIENCE,
        now: Callable[[], int] | None = None,
        l2_ttl_seconds: int = 3600,
        l3_ttl_seconds: int = 300,
        jwt_issuer: str | None = None,
        idempotency_key: str | Callable[[Mapping[str, Any]], str | None] | None = None,
        include_readable_transaction_fields: bool = False,
    ) -> None:
        self._issuer = issuer
        self._issue_request = issue_request
        self._owner_private_jwk = owner_private_jwk
        self._owner_kid = owner_kid
        self._agent_private_jwk = agent_private_jwk
        self._agent_public_jwk = agent_public_jwk
        self._agent_kid = agent_kid
        self._constraints = constraints
        self._audience = audience
        self._now = now
        self._l2_ttl_seconds = l2_ttl_seconds
        self._l3_ttl_seconds = l3_ttl_seconds
        self._jwt_issuer = jwt_issuer
        self._idempotency_key = idempotency_key
        self._include_readable_transaction_fields = include_readable_transaction_fields

    def prepare_evidence(self, input_data: Mapping[str, Any]) -> Mapping[str, Any]:
        issue_request = self._resolve_issue_request(input_data)
        owner_public_jwk = issue_request.get('ownerPublicJwk') or issue_request.get('owner_public_jwk')
        expected_owner_public_jwk = public_jwk_from_private_jwk(self._owner_private_jwk)
        if owner_public_jwk is None:
            issue_request = {**issue_request, 'ownerPublicJwk': expected_owner_public_jwk}
        else:
            _assert_same_public_jwk(owner_public_jwk, expected_owner_public_jwk, 'owner_public_jwk')

        l1_credential = normalize_chain_node(self._issue_l1(issue_request, input_data), 'sd+jwt')
        l1_presentation = chain_node_presentation(l1_credential)
        agent_public_jwk = self._agent_public_jwk or public_jwk_from_private_jwk(self._agent_private_jwk)
        _assert_same_public_jwk(agent_public_jwk, public_jwk_from_private_jwk(self._agent_private_jwk), 'agent_public_jwk')
        agent_kid = self._agent_kid or _optional_text(agent_public_jwk.get('kid')) or _optional_text(self._agent_private_jwk.get('kid'))
        if not agent_kid:
            raise ValueError('agent_kid_required')
        constraints = self._constraints(input_data) if callable(self._constraints) else self._constraints or {}
        l2_delegation = sign_l2_delegation(
            owner_private_jwk=self._owner_private_jwk,
            owner_kid=self._owner_kid,
            agent_public_jwk={**dict(agent_public_jwk), 'kid': agent_kid},
            agent_kid=agent_kid,
            l1_presentation=l1_presentation,
            constraints=constraints,
            audience=self._audience,
            issuer=self._jwt_issuer or 'owner',
            now=self._now() if self._now else None,
            ttl_seconds=self._l2_ttl_seconds,
        )
        local_provider = LocalProducerProvider(
            delegation=LocalProducerDelegation(
                l1_credential=l1_credential,
                l2_delegation=l2_delegation,
                agent_private_jwk=self._agent_private_jwk,
                agent_kid=agent_kid,
            ),
            audience=self._audience,
            now=self._now,
            ttl_seconds=self._l3_ttl_seconds,
            issuer=self._jwt_issuer,
            idempotency_key=self._idempotency_key,
            include_readable_transaction_fields=self._include_readable_transaction_fields,
        )
        return local_provider.prepare_evidence(input_data)

    def _resolve_issue_request(self, input_data: Mapping[str, Any]) -> dict[str, Any]:
        request = self._issue_request(input_data) if callable(self._issue_request) else self._issue_request
        if not isinstance(request, Mapping):
            raise ValueError('remote_issuer_issue_request_required')
        subject = _require_text(request.get('subject'), 'remote_issuer_subject')
        return {**dict(request), 'subject': subject}

    def _issue_l1(self, request: Mapping[str, Any], input_data: Mapping[str, Any]) -> ChainNode:
        if isinstance(self._issuer, RemoteIssuerSource):
            return self._issuer.issue_l1(request)
        return _l1_credential_from_response(self._issuer(request, input_data))


def generate_ec_private_jwk(*, kid: str | None = None) -> dict[str, str]:
    key = ec.generate_private_key(ec.SECP256R1())
    private_numbers = key.private_numbers()
    public_numbers = private_numbers.public_numbers
    jwk = {
        'kty': 'EC',
        'crv': 'P-256',
        'x': _b64url_int(public_numbers.x),
        'y': _b64url_int(public_numbers.y),
        'd': _b64url_int(private_numbers.private_value),
    }
    if kid:
        jwk['kid'] = kid
    return jwk


def public_jwk_from_private_jwk(private_jwk: JWK, *, kid: str | None = None) -> dict[str, Any]:
    _assert_ec_private_jwk(private_jwk, 'private_jwk')
    public_jwk = {
        key: private_jwk[key]
        for key in ('kty', 'crv', 'x', 'y')
        if isinstance(private_jwk.get(key), str)
    }
    resolved_kid = kid or _optional_text(private_jwk.get('kid'))
    if resolved_kid:
        public_jwk['kid'] = resolved_kid
    return public_jwk


def sd_hash_of_presentation(presentation: str) -> str:
    if not isinstance(presentation, str) or not presentation:
        raise ValueError('presentation_must_be_non_empty_string')
    return _b64url(hashlib.sha256(_ascii_bytes(presentation)).digest())


def sign_l2_delegation(
    *,
    owner_private_jwk: JWK,
    agent_public_jwk: JWK,
    owner_kid: str | None = None,
    agent_kid: str | None = None,
    l1_presentation: str | None = None,
    sd_hash: str | None = None,
    constraints: Mapping[str, Any] | None = None,
    vct: str = TRUSTLINE_VI_L2_VCT,
    issuer: str = 'owner',
    audience: str = TRUSTLINE_VI_AUDIENCE,
    now: int | None = None,
    ttl_seconds: int = 3600,
    nonce: str | None = None,
    disclosure_salt: bytes | str | None = None,
) -> str:
    _assert_ec_private_jwk(owner_private_jwk, 'owner_private_jwk')
    _assert_ec_public_jwk(agent_public_jwk, 'agent_public_jwk')
    resolved_hash = sd_hash or (
        sd_hash_of_presentation(l1_presentation) if l1_presentation else None
    )
    if not resolved_hash:
        raise ValueError('sd_hash_or_l1_presentation_required')
    resolved_agent_kid = agent_kid or _optional_text(agent_public_jwk.get('kid'))
    if not resolved_agent_kid:
        raise ValueError('agent_kid_required')

    disclosure, digest = _make_disclosure('constraints', dict(constraints or {}), disclosure_salt)
    issued_at = int(now if now is not None else _now())
    agent_cnf = dict(agent_public_jwk)
    agent_cnf.pop('d', None)
    agent_cnf['kid'] = resolved_agent_kid
    header = {'alg': 'ES256', 'typ': 'kb-sd-jwt+kb'}
    if owner_kid:
        header['kid'] = owner_kid
    payload = {
        'vct': vct,
        'sd_hash': resolved_hash,
        'cnf': {'jwk': agent_cnf},
        'nonce': nonce or _random_id(),
        '_sd': [digest],
        '_sd_alg': 'sha-256',
        'iss': issuer,
        'aud': audience,
        'iat': issued_at,
        'exp': issued_at + int(ttl_seconds),
    }
    jws = _sign_jws(header, payload, owner_private_jwk)
    return f'{jws}~{disclosure}~'


def sign_l3_final_action(
    *,
    agent_private_jwk: JWK,
    agent_kid: str,
    transaction: Mapping[str, Any],
    l2_presentation: str | None = None,
    sd_hash: str | None = None,
    idempotency_key: str | None = None,
    nonce: str | None = None,
    issuer: str = 'agent',
    audience: str = TRUSTLINE_VI_AUDIENCE,
    now: int | None = None,
    ttl_seconds: int = 300,
) -> str:
    _assert_ec_private_jwk(agent_private_jwk, 'agent_private_jwk')
    if not isinstance(agent_kid, str) or not agent_kid.strip():
        raise ValueError('agent_kid_required')
    resolved_hash = sd_hash or (
        sd_hash_of_presentation(l2_presentation) if l2_presentation else None
    )
    if not resolved_hash:
        raise ValueError('sd_hash_or_l2_presentation_required')
    for key in ('paymentRequirementsHash', 'invoiceId'):
        if not transaction.get(key):
            raise ValueError(f'transaction.{key}_required')

    issued_at = int(now if now is not None else _now())
    payload = {
        'sd_hash': resolved_hash,
        'transaction': dict(transaction),
        'idempotencyKey': idempotency_key or _random_id(),
        'nonce': nonce or _random_id(),
        'iss': issuer,
        'aud': audience,
        'iat': issued_at,
        'exp': issued_at + int(ttl_seconds),
    }
    jws = _sign_jws(
        {'alg': 'ES256', 'typ': 'kb-sd-jwt', 'kid': agent_kid.strip()},
        payload,
        agent_private_jwk,
    )
    return f'{jws}~'


def build_verifiable_intent_chain(
    *,
    l1_credential: ChainNode,
    l2_delegation: ChainNode,
    l3_final_action: ChainNode,
    issuer_kid: str | None = None,
) -> dict[str, Any]:
    l1 = normalize_chain_node(l1_credential, 'sd+jwt')
    if issuer_kid and not l1.get('kid'):
        l1['kid'] = issuer_kid
    return {
        'l1Credential': l1,
        'l2Delegation': normalize_chain_node(l2_delegation, 'kb-sd-jwt+kb'),
        'l3FinalAction': normalize_chain_node(l3_final_action, 'kb-sd-jwt'),
    }


def normalize_chain_node(value: ChainNode, default_format: str) -> dict[str, Any]:
    if isinstance(value, str):
        return {'format': default_format, 'sdJwt': value}
    if isinstance(value, Mapping):
        node = dict(value)
        node.setdefault('format', default_format)
        return node
    raise ValueError('verifiable_intent_chain_node_invalid')


def chain_node_presentation(node: Mapping[str, Any]) -> str:
    value = node.get('sdJwt') or node.get('jwt')
    if not isinstance(value, str) or not value.strip():
        raise ValueError('verifiable_intent_chain_node_missing_sd_jwt')
    return value


def _sign_jws(header: Mapping[str, Any], payload: Mapping[str, Any], private_jwk: JWK) -> str:
    key = _private_key_from_jwk(private_jwk)
    protected = _b64url(_json_bytes(header))
    body = _b64url(_json_bytes(payload))
    signing_input = f'{protected}.{body}'.encode('ascii')
    der_signature = key.sign(signing_input, ec.ECDSA(hashes.SHA256()))
    r, s = utils.decode_dss_signature(der_signature)
    signature = r.to_bytes(32, 'big') + s.to_bytes(32, 'big')
    return f'{protected}.{body}.{_b64url(signature)}'


def _private_key_from_jwk(private_jwk: JWK) -> ec.EllipticCurvePrivateKey:
    _assert_ec_private_jwk(private_jwk, 'private_jwk')
    public_numbers = ec.EllipticCurvePublicNumbers(
        _b64url_to_int(str(private_jwk['x'])),
        _b64url_to_int(str(private_jwk['y'])),
        ec.SECP256R1(),
    )
    private_numbers = ec.EllipticCurvePrivateNumbers(
        _b64url_to_int(str(private_jwk['d'])),
        public_numbers,
    )
    return private_numbers.private_key()


def _assert_ec_private_jwk(value: JWK, label: str) -> None:
    if not isinstance(value, Mapping) or value.get('kty') != 'EC' or not value.get('d'):
        raise ValueError(f'{label}_must_be_ec_private_jwk')
    _assert_p256_jwk(value, label)


def _assert_ec_public_jwk(value: JWK, label: str) -> None:
    if not isinstance(value, Mapping) or value.get('kty') != 'EC':
        raise ValueError(f'{label}_must_be_ec_public_jwk')
    if value.get('d'):
        raise ValueError(f'{label}_must_not_include_private_scalar')
    _assert_p256_jwk(value, label)


def _assert_same_public_jwk(actual: Any, expected: JWK, label: str) -> None:
    if not isinstance(actual, Mapping):
        raise ValueError(f'{label}_must_be_ec_public_jwk')
    _assert_ec_public_jwk(actual, label)
    if (
        actual.get('kty') != expected.get('kty')
        or actual.get('crv') != expected.get('crv')
        or actual.get('x') != expected.get('x')
        or actual.get('y') != expected.get('y')
    ):
        raise ValueError(f'{label}_must_match_private_key')


def _assert_p256_jwk(value: JWK, label: str) -> None:
    if value.get('crv') not in (None, 'P-256'):
        raise ValueError(f'{label}_must_use_p256')
    if not isinstance(value.get('x'), str) or not isinstance(value.get('y'), str):
        raise ValueError(f'{label}_must_include_public_coordinates')


def _make_disclosure(name: str, value: Any, salt: bytes | str | None = None) -> tuple[str, str]:
    salt_text = salt if isinstance(salt, str) else _b64url(salt or os.urandom(16))
    disclosure = _b64url(_json_bytes([salt_text, name, value]))
    digest = _b64url(hashlib.sha256(_ascii_bytes(disclosure)).digest())
    return disclosure, digest


def _invoice_id_from_payment_requirements(payment_requirements: Any) -> str:
    if isinstance(payment_requirements, Mapping):
        wire = payment_requirements
    else:
        to_dict = getattr(payment_requirements, 'to_dict', None)
        if not callable(to_dict):
            raise ValueError('invalid_payment_requirements')
        wire = to_dict()
        if not isinstance(wire, Mapping):
            raise ValueError('invalid_payment_requirements')
    extra = wire.get('extra')
    if not isinstance(extra, Mapping):
        raise ValueError('payment_requirements_invoice_id_required')
    invoice_id = extra.get('invoiceId') or extra.get('invoice_id')
    if not isinstance(invoice_id, str) or not invoice_id.strip():
        raise ValueError('payment_requirements_invoice_id_required')
    return invoice_id.strip()


def _text_field(value: Any) -> str | None:
    if isinstance(value, str) and value.strip():
        return value.strip()
    if isinstance(value, (int, float)) and not isinstance(value, bool):
        return str(value)
    return None


def _mapping_field(value: Any) -> Mapping[str, Any] | None:
    return value if isinstance(value, Mapping) else None


def _readable_transaction_fields(
    payment_requirements: Any,
    input_data: Mapping[str, Any],
) -> dict[str, Any]:
    if isinstance(payment_requirements, Mapping):
        requirements = payment_requirements
    else:
        to_dict = getattr(payment_requirements, 'to_dict', None)
        requirements = to_dict() if callable(to_dict) else {}
        if not isinstance(requirements, Mapping):
            requirements = {}
    network = _text_field(requirements.get('network'))
    chain = _text_field(requirements.get('chain')) or (network.split(':')[0] if network else None)
    payment_required = _mapping_field(input_data.get('paymentRequired'))
    resource = _mapping_field(payment_required.get('resource')) if payment_required else None
    values = {
        'chain': chain,
        'network': network,
        'asset': _text_field(requirements.get('asset') or requirements.get('currency')),
        'amount': _text_field(requirements.get('amount')),
        'payTo': _text_field(requirements.get('payTo') or requirements.get('pay_to')),
        'merchantUrl': _text_field(resource.get('url')) if resource else None,
    }
    return {key: value for key, value in values.items() if value}


def _delegation_get(delegation: LocalProducerDelegation | Mapping[str, Any], key: str) -> Any:
    if isinstance(delegation, LocalProducerDelegation):
        return getattr(delegation, key)
    if key in delegation:
        return delegation[key]
    camel = _snake_to_camel(key)
    if camel in delegation:
        return delegation[camel]
    raise ValueError(f'{key}_required')


def _delegation_get_optional(
    delegation: LocalProducerDelegation | Mapping[str, Any],
    key: str,
) -> Any:
    if isinstance(delegation, LocalProducerDelegation):
        return getattr(delegation, key)
    if key in delegation:
        return delegation[key]
    return delegation.get(_snake_to_camel(key))


def _snake_to_camel(value: str) -> str:
    head, *tail = value.split('_')
    return head + ''.join(part[:1].upper() + part[1:] for part in tail)


def _optional_text(value: Any) -> str | None:
    return value.strip() if isinstance(value, str) and value.strip() else None


def _require_text(value: Any, label: str) -> str:
    if not isinstance(value, str) or not value.strip():
        raise ValueError(f'{label}_required')
    return value.strip()


def _l1_credential_from_response(response: Any) -> ChainNode:
    if isinstance(response, str):
        return response
    if not isinstance(response, Mapping):
        raise ValueError('remote_issuer_l1_missing_credential')
    if 'l1Credential' in response:
        return _l1_credential_from_response(response['l1Credential'])
    node = normalize_chain_node(response, 'sd+jwt')
    chain_node_presentation(node)
    return node


def _default_post_json(url: str, body: Mapping[str, Any], headers: Mapping[str, str]) -> Mapping[str, Any]:
    request = urllib.request.Request(
        url,
        data=json.dumps(body, separators=(',', ':'), ensure_ascii=False).encode('utf-8'),
        headers={'content-type': 'application/json', **dict(headers)},
        method='POST',
    )
    try:
        with urllib.request.urlopen(request, timeout=30) as response:  # noqa: S310 - caller controls issuer endpoint.
            payload = response.read().decode('utf-8')
    except urllib.error.HTTPError as exc:
        raise ValueError(f'remote_issuer_l1_failed:{exc.code}') from exc
    if not payload:
        raise ValueError('remote_issuer_l1_missing_credential')
    decoded = json.loads(payload)
    if not isinstance(decoded, Mapping):
        raise ValueError('remote_issuer_l1_missing_credential')
    return decoded


def _now() -> int:
    return int(time.time())


def _random_id() -> str:
    return str(uuid.uuid4())


def _ascii_bytes(value: str) -> bytes:
    try:
        return value.encode('ascii')
    except UnicodeEncodeError as exc:
        raise ValueError('sd_jwt_presentation_must_be_ascii') from exc


def _json_bytes(value: Any) -> bytes:
    return json.dumps(value, separators=(',', ':'), ensure_ascii=False).encode('utf-8')


def _b64url(data: bytes) -> str:
    return base64.urlsafe_b64encode(data).rstrip(b'=').decode('ascii')


def _b64url_int(value: int) -> str:
    return _b64url(value.to_bytes(32, 'big'))


def _b64url_to_int(value: str) -> int:
    padded = value + '=' * (-len(value) % 4)
    return int.from_bytes(base64.urlsafe_b64decode(padded.encode('ascii')), 'big')
