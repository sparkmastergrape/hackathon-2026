from __future__ import annotations

import base64
import hashlib
import json
import math
from dataclasses import dataclass
from decimal import Decimal, InvalidOperation
from typing import Any, Literal, Mapping, Optional

from xrpl.clients import JsonRpcClient
from xrpl.ledger import get_latest_validated_ledger_sequence
from xrpl.models.amounts import IssuedCurrencyAmount
from xrpl.models.transactions import Memo, Payment
from xrpl.models.requests import ServerInfo
from xrpl.transaction import autofill, sign
from xrpl.wallet import Wallet

from x402_xrpl.types import PaymentPayload, PaymentRequirements, ResourceInfo

InvoiceBindingMode = Literal["memos", "invoice_id", "both"]
XRPLNetworkId = Literal["xrpl:0", "xrpl:1", "xrpl:2"]

# Typed facilitator memo (shared on-chain shape). The payer stamps this as an
# ADDITIONAL XRPL Memo next to the invoice memo whenever the merchant-relayed
# PaymentRequirements carries an extra.facilitator object with a non-empty id.
FACILITATOR_MEMO_TYPE = "urn:x402:facilitator"
FACILITATOR_MEMO_FORMAT = "application/json"


def text_to_memo_hex(text: str) -> str:
    """
    Encode a UTF-8 string and return uppercase hex suitable for XRPL Memo fields.
    """
    return text.encode("utf-8").hex().upper()


def invoice_id_to_memo_hex(invoice_id: str) -> str:
    """
    Encode an invoice id as UTF-8 and return uppercase hex suitable for MemoData.
    """
    return text_to_memo_hex(invoice_id)


# Total XRP supply in drops (1e17). Mirrors the facilitator verifier's MAX_XRP_DROPS:
# a SendMax above this is structurally impossible; a non-positive one can never settle.
_MAX_XRP_DROPS = 100_000_000_000_000_000


def _is_drops_string(value: Any) -> bool:
    """True iff value is a POSITIVE XRP drops string (1..MAX_XRP_DROPS).

    Mirrors the facilitator verifier's _is_drops_string so a malformed source
    SendMax is refused before signing instead of wasting a signed transaction.
    """
    if not isinstance(value, str) or not value.isdigit():
        return False
    try:
        drops = int(value)
    except ValueError:
        return False
    return 1 <= drops <= _MAX_XRP_DROPS


def _is_wellformed_iou_send_max(value: Any) -> bool:
    """True iff value is a well-formed IOU SendMax with a strictly POSITIVE value.

    Accepts an xrpl IssuedCurrencyAmount or a plain mapping with string
    currency/issuer/value, mirroring the facilitator's _is_wellformed_iou_amount.
    """
    if isinstance(value, IssuedCurrencyAmount):
        currency, issuer, amount = value.currency, value.issuer, value.value
    elif isinstance(value, Mapping):
        currency = value.get("currency")
        issuer = value.get("issuer")
        amount = value.get("value")
    else:
        return False
    if not (isinstance(currency, str) and isinstance(issuer, str) and isinstance(amount, str)):
        return False
    try:
        return Decimal(amount) > 0
    except (InvalidOperation, ValueError, TypeError):
        return False


def invoice_id_to_invoice_id_field(invoice_id: str) -> str:
    """
    Encode an invoice id into the XRPL Payment.InvoiceID field as SHA-256(invoice_id).
    """
    return hashlib.sha256(invoice_id.encode("utf-8")).hexdigest().upper()


def build_payment_header_for_signed_blob(
    *,
    req: PaymentRequirements,
    signed_tx_blob: str,
    invoice_id: str,
    extensions: Mapping[str, Any] | None = None,
    resource: ResourceInfo | None = None,
) -> str:
    """
    Build the base64 JSON envelope for the PAYMENT-SIGNATURE header.
    """
    _assert_invoice_matches(req, invoice_id)
    payment_payload = PaymentPayload(
        x402_version=2,
        resource=resource,
        accepted=req,
        payload={"signedTxBlob": signed_tx_blob, "invoiceId": invoice_id},
        extensions=extensions,
    )
    return base64.b64encode(
        json.dumps(payment_payload.to_dict(), separators=(",", ":"), sort_keys=True).encode("utf-8")
    ).decode("utf-8")


@dataclass(frozen=True)
class XRPLPresignedPaymentPayerOptions:
    wallet: Wallet
    network: XRPLNetworkId
    rpc_url: str
    invoice_binding: InvoiceBindingMode = "both"
    max_fee_drops: int = 10_000

    def __post_init__(self) -> None:
        if type(self.max_fee_drops) is not int or not 1 <= self.max_fee_drops <= _MAX_XRP_DROPS:
            raise ValueError("max_fee_drops must be a positive XRP drops integer")


@dataclass(frozen=True)
class XRPLPresignedPreparedPayment:
    payment_payload: PaymentPayload
    payment_header: str
    signed_tx_blob: str
    invoice_id: str


class XRPLPresignedPaymentPayer:
    """
    Client-side helper that:
      - validates PaymentRequirements for XRPL exact presigned payments
      - builds an XRPL Payment transaction (XRP + direct IOU v1)
      - binds invoiceId into the tx (Memos and/or InvoiceID)
      - autofills + signs to a tx blob (hex)
      - returns PAYMENT-SIGNATURE header value (base64 JSON PaymentPayload)
    """

    def __init__(
        self,
        options: XRPLPresignedPaymentPayerOptions,
        *,
        client: Optional[JsonRpcClient] = None,
    ) -> None:
        self._options = options
        self._client = client or JsonRpcClient(options.rpc_url)

    def supports(self, req: PaymentRequirements) -> bool:
        if req.network != self._options.network:
            return False
        if req.scheme != "exact":
            return False
        if req.network not in ("xrpl:0", "xrpl:1", "xrpl:2"):
            return False
        asset = str(req.asset or "XRP")
        if asset.upper() == "XRP":
            return True
        try:
            to_currency_hex(asset)
        except ValueError:
            return False
        return _issuer_from_payment_req(req) is not None

    def prepare_payment(
        self,
        req: PaymentRequirements,
        *,
        invoice_id: Optional[str] = None,
        extensions: Mapping[str, Any] | None = None,
        pay_with: "str | IssuedCurrencyAmount | None" = None,
        resource: ResourceInfo | None = None,
    ) -> XRPLPresignedPreparedPayment:
        if not self.supports(req):
            raise ValueError("PaymentRequirements not supported by XRPLPresignedPaymentPayer")

        inv = invoice_id if invoice_id is not None else req.invoice_id()
        if not inv:
            raise ValueError('invoice_id is required (expected PaymentRequirements.extra["invoiceId"])')
        _assert_invoice_matches(req, inv)

        memo_list: list[Memo] | None = None
        invoice_id_field: str | None = None

        if self._options.invoice_binding in ("memos", "both"):
            memo_list = [Memo(memo_data=invoice_id_to_memo_hex(inv))]

        if self._options.invoice_binding in ("invoice_id", "both"):
            invoice_id_field = invoice_id_to_invoice_id_field(inv)

        destination_tag: int | None = None
        if isinstance(req.extra, Mapping):
            raw_tag = req.extra.get("destinationTag")
            if raw_tag is not None:
                try:
                    destination_tag = int(raw_tag)
                except Exception as exc:
                    raise ValueError('destinationTag must be an integer (expected PaymentRequirements.extra["destinationTag"])') from exc

        source_tag: int | None = None
        if isinstance(req.extra, Mapping):
            raw_source_tag = req.extra.get("sourceTag")
            if raw_source_tag is not None:
                try:
                    source_tag = int(raw_source_tag)
                except Exception as exc:
                    raise ValueError('sourceTag must be an integer (expected PaymentRequirements.extra["sourceTag"])') from exc

        # Typed facilitator memo (zero-config): emit whenever extra.facilitator
        # carries a non-empty id. The sourceTag inside the memo MUST equal the
        # resolved Payment.SourceTag (this is the binding).
        facilitator = _facilitator_from_payment_req(req)
        if facilitator is not None:
            fac_id, fac_name = facilitator
            # Build the MemoData JSON with keys in SPEC order: id, name, sourceTag.
            facilitator_obj: dict[str, Any] = {"id": fac_id}
            if fac_name:
                facilitator_obj["name"] = fac_name
            if source_tag is not None:
                facilitator_obj["sourceTag"] = source_tag
            facilitator_memo = Memo(
                memo_type=text_to_memo_hex(FACILITATOR_MEMO_TYPE),
                memo_data=text_to_memo_hex(
                    json.dumps(facilitator_obj, separators=(",", ":"))
                ),
                memo_format=text_to_memo_hex(FACILITATOR_MEMO_FORMAT),
            )
            # Invoice-memo coexistence guard: the facilitator verify requires the
            # invoiceId to appear among decoded memos whenever Memos is non-empty.
            # If the current binding mode would not emit the invoice memo, force it.
            if memo_list is None:
                memo_list = [Memo(memo_data=invoice_id_to_memo_hex(inv))]
            memo_list.append(facilitator_memo)

        asset = str(req.asset or "XRP")
        if asset.upper() == "XRP":
            amount: str | IssuedCurrencyAmount = str(int(req.amount))
            default_send_max: str | IssuedCurrencyAmount | None = None
        else:
            issuer = _issuer_from_payment_req(req)
            if not issuer:
                raise ValueError('issuer is required for IOU payments (expected PaymentRequirements.extra["issuer"])')
            currency_hex = to_currency_hex(asset)
            amount = IssuedCurrencyAmount(
                currency=currency_hex,
                issuer=issuer,
                value=str(req.amount),
            )
            # IOU policy: include SendMax (same currency+issuer, value >= destination value).
            default_send_max = IssuedCurrencyAmount(
                currency=currency_hex,
                issuer=issuer,
                value=str(req.amount),
            )

        if pay_with is not None:
            # opt-in required: merchant must advertise crossCurrency
            extra = req.extra if isinstance(req.extra, Mapping) else {}
            if extra.get("crossCurrency") is not True:
                raise ValueError("cross-currency requires PaymentRequirements.extra[\"crossCurrency\"] = true")
            # A drops-string source funds an XRP-destination payment from XRP, which is
            # NOT cross-currency and would be rejected by the facilitator. Fail fast and
            # stay consistent with the verifier (mirrors the Node payer guard).
            if asset.upper() == "XRP" and isinstance(pay_with, str):
                raise ValueError(
                    "pay_with as an XRP drops string is not valid for an XRP-destination "
                    "payment (that is not cross-currency)"
                )
            # Validate the source SendMax is well-formed BEFORE signing — mirror the
            # facilitator's _is_drops_string / _is_wellformed_iou_amount so a malformed
            # value (non-positive, overlarge, garbage) is refused here instead of wasting
            # a signed transaction the verifier rejects (unsupported_payment_features).
            if isinstance(pay_with, str):
                if not _is_drops_string(pay_with):
                    raise ValueError(
                        "pay_with drops string must be a positive integer in 1..MAX_XRP_DROPS"
                    )
            elif not _is_wellformed_iou_send_max(pay_with):
                raise ValueError(
                    "pay_with IOU SendMax must have string currency/issuer and a positive value"
                )
            send_max: str | IssuedCurrencyAmount | None = pay_with
        else:
            send_max = default_send_max

        # Bind maxTimeoutSeconds to LastLedgerSequence (ledger-based expiry).
        current_validated_ledger = get_latest_validated_ledger_sequence(self._client)
        max_ledger_delta = int(math.ceil(int(req.max_timeout_seconds) / 5.0) + 2)
        last_ledger_sequence = int(current_validated_ledger) + max_ledger_delta

        payment_tx = Payment(
            account=self._options.wallet.classic_address,
            destination=req.pay_to,
            amount=amount,
            send_max=send_max,
            memos=memo_list,
            invoice_id=invoice_id_field,
            source_tag=source_tag,
            destination_tag=destination_tag,
            last_ledger_sequence=last_ledger_sequence,
        )

        filled = autofill(payment_tx, self._client)
        server = self._client.request(ServerInfo())
        info = (server.result or {}).get("info")
        network_id = info.get("network_id") if isinstance(info, Mapping) else None
        expected_network_id = int(self._options.network.split(":")[1])
        if (
            type(network_id) is not int
            or network_id != expected_network_id
            or (filled.network_id is not None and filled.network_id != expected_network_id)
        ):
            raise ValueError("rpc_network_mismatch_or_unknown")
        if (
            not isinstance(filled.fee, str)
            or not filled.fee.isascii()
            or not filled.fee.isdigit()
            or not 1 <= int(filled.fee) <= self._options.max_fee_drops
        ):
            raise ValueError("fee_exceeds_payer_policy")
        signed = sign(filled, self._options.wallet)
        signed_blob = signed.blob()

        payment_payload = PaymentPayload(
            x402_version=2,
            resource=resource,
            accepted=req,
            payload={"signedTxBlob": signed_blob, "invoiceId": inv},
            extensions=extensions,
        )
        header = base64.b64encode(
            json.dumps(payment_payload.to_dict(), separators=(",", ":"), sort_keys=True).encode("utf-8")
        ).decode("utf-8")

        return XRPLPresignedPreparedPayment(
            payment_payload=payment_payload,
            payment_header=header,
            signed_tx_blob=signed_blob,
            invoice_id=inv,
        )

    def create_payment_header(
        self,
        req: PaymentRequirements,
        *,
        invoice_id: Optional[str] = None,
        extensions: Mapping[str, Any] | None = None,
        pay_with: "str | IssuedCurrencyAmount | None" = None,
        resource: ResourceInfo | None = None,
    ) -> str:
        return self.prepare_payment(
            req,
            invoice_id=invoice_id,
            extensions=extensions,
            pay_with=pay_with,
            resource=resource,
        ).payment_header


def _assert_invoice_matches(req: PaymentRequirements, invoice_id: str) -> None:
    extra = req.extra or {}
    if "invoiceId" in extra and extra["invoiceId"] != invoice_id:
        raise ValueError("invoice_id_mismatch")


def _issuer_from_payment_req(req: PaymentRequirements) -> Optional[str]:
    extra = req.extra
    if not isinstance(extra, Mapping):
        return None
    issuer = extra.get("issuer")
    if not isinstance(issuer, str) or not issuer:
        return None
    return issuer


def _facilitator_from_payment_req(
    req: PaymentRequirements,
) -> Optional[tuple[str, Optional[str]]]:
    """
    Extract and validate the (id, name) pair from req.extra.facilitator per SPEC.

    Returns None when there is no facilitator object or no non-empty id (legacy
    behavior: emit no facilitator memo). Only `id` and `name` are whitelisted; no
    other keys are copied from the merchant-relayed object.

    - id: required, trimmed non-empty string, capped at 64 chars.
    - name: optional, trimmed string capped at 128 chars; None when absent/empty.
    """
    extra = req.extra
    if not isinstance(extra, Mapping):
        return None
    facilitator = extra.get("facilitator")
    if not isinstance(facilitator, Mapping):
        return None

    raw_id = facilitator.get("id")
    if not isinstance(raw_id, str):
        return None
    fac_id = raw_id.strip()
    if not fac_id:
        return None
    fac_id = fac_id[:64]

    fac_name: Optional[str] = None
    raw_name = facilitator.get("name")
    if isinstance(raw_name, str):
        trimmed_name = raw_name.strip()
        if trimmed_name:
            fac_name = trimmed_name[:128]

    return fac_id, fac_name


def to_currency_hex(code: str) -> str:
    """
    Normalize an XRPL currency code to a valid XRPL JSON representation.

    Accepted inputs:
    - 3-character code (e.g. "USD") → returns uppercase 3-char
    - 40-char hex (160-bit currency code) → returns uppercase 40-hex

    NOTE: Per this repo’s XRPL x402 exact presigned-payment spec, IOU `asset`
    values MUST be either 3-char or 40-hex (do not pass longer strings like
    "RLUSD"; use the 160-bit hex currency code instead).
    """
    code = code.strip()
    if len(code) == 40:
        try:
            bytes.fromhex(code)
            return code.upper()
        except ValueError:
            pass

    if len(code) == 3:
        return code.upper()

    raise ValueError('Invalid XRPL currency code (expected 3 chars or 40-hex).')
