"""Client helpers for the XRPL `upto` scheme (native Checks).

Spec: app/docs/specs/schemes/upto/scheme_upto_xrpl.md

Two sides:

- **Payer** builds and signs a ``CheckCreate`` whose ``SendMax`` is the authorized
  ceiling, and presents it as the payment payload.
- **Merchant** derives the CheckID from that signed blob and signs a ``CheckCash``
  for the metered amount once the work is done.

The CheckID is derivable before the ``Check`` exists, which is what lets the
merchant sign against it ahead of submission.
"""

from __future__ import annotations

import base64
import hashlib
import json
import math
import time
from collections.abc import Mapping
from dataclasses import dataclass
from typing import Any, Optional, Union

from xrpl.clients import JsonRpcClient
from xrpl.core.addresscodec import decode_classic_address
from xrpl.core.binarycodec import decode as xrpl_decode
from xrpl.ledger import get_latest_validated_ledger_sequence
from xrpl.models.amounts import IssuedCurrencyAmount
from xrpl.models.transactions import CheckCash, CheckCreate
from xrpl.transaction import autofill, sign
from xrpl.wallet import Wallet

from ..types import PaymentPayload, PaymentRequirements
from .presigned_payment_payer import (
    XRPLNetworkId,
    invoice_id_to_invoice_id_field,
    to_currency_hex,
)

# XRPL timestamps count seconds from 2000-01-01T00:00:00Z.
RIPPLE_EPOCH_OFFSET = 946_684_800
# 'C' — the Check ledger-object space key.
CHECK_SPACE_KEY = b"\x00\x43"

XRPLAmount = Union[str, IssuedCurrencyAmount]


def unix_to_ripple_time(unix_seconds: float) -> int:
    """Convert a UNIX timestamp to XRPL (Ripple epoch) seconds."""
    ripple = int(unix_seconds) - RIPPLE_EPOCH_OFFSET
    if ripple < 0:
        raise ValueError("timestamp precedes the Ripple epoch (2000-01-01Z)")
    return ripple


def derive_check_id(account: str, sequence: int) -> str:
    """``CheckID = SHA512Half(0x0043 || AccountID || UInt32(Sequence))``.

    Derivable before the ``CheckCreate`` is submitted, so the merchant can sign a
    ``CheckCash`` for a Check that does not exist yet.
    """
    seq = int(sequence)
    if seq < 0 or seq > 2**32 - 1:
        raise ValueError("sequence out of uint32 range")
    preimage = CHECK_SPACE_KEY + decode_classic_address(account) + seq.to_bytes(4, "big")
    return hashlib.sha512(preimage).hexdigest()[:64].upper()


def check_id_from_signed_check_create(signed_check_create_blob: str) -> str:
    """Derive the CheckID from a signed ``CheckCreate`` blob."""
    tx_json = xrpl_decode(signed_check_create_blob)
    if tx_json.get("TransactionType") != "CheckCreate":
        raise ValueError("blob is not a CheckCreate")
    if tx_json.get("TicketSequence") is not None:
        # Sequence would be 0 and the object would key off TicketSequence instead.
        raise ValueError("CheckCreate used a Ticket; unsupported by the upto scheme")
    account = tx_json.get("Account")
    sequence = tx_json.get("Sequence")
    if not isinstance(account, str) or sequence is None:
        raise ValueError("CheckCreate is missing Account or Sequence")
    return derive_check_id(account, int(sequence))


def _send_max_for_requirements(req: PaymentRequirements) -> XRPLAmount:
    """The ceiling, expressed as an XRPL amount for the requirement's asset."""
    asset = str(req.asset or "XRP")
    if asset.upper() == "XRP":
        return str(int(req.amount))
    issuer = None
    extra = req.extra or {}
    if isinstance(extra, Mapping):
        candidate = extra.get("issuer")
        if isinstance(candidate, str) and candidate:
            issuer = candidate
    if not issuer:
        raise ValueError("issuer is required for a non-XRP upto requirement")
    return IssuedCurrencyAmount(
        currency=to_currency_hex(asset), issuer=issuer, value=str(req.amount)
    )


def _source_tag_from_requirements(req: PaymentRequirements) -> Optional[int]:
    """Attribution tag the facilitator enforces on both transactions."""
    extra = req.extra
    if not isinstance(extra, Mapping):
        return None
    raw = extra.get("sourceTag")
    if raw is None:
        return None
    try:
        return int(raw)
    except Exception as exc:  # pragma: no cover - defensive
        raise ValueError(
            'sourceTag must be an integer (expected PaymentRequirements.extra["sourceTag"])'
        ) from exc


def _ledger_horizon(client: JsonRpcClient, max_timeout_seconds: int) -> int:
    current = get_latest_validated_ledger_sequence(client)
    return int(current) + int(math.ceil(int(max_timeout_seconds) / 5.0) + 2)


@dataclass(frozen=True)
class XRPLUptoPayerOptions:
    wallet: Wallet
    network: XRPLNetworkId
    rpc_url: str
    # Authorization lifetime. Kept short: it bounds how long the merchant carries
    # payer-balance risk between create and cash.
    authorization_ttl_seconds: int = 300


@dataclass(frozen=True)
class XRPLUptoAuthorization:
    payment_payload: PaymentPayload
    payment_header: str
    signed_check_create_blob: str
    check_id: str
    invoice_id: str
    ceiling: XRPLAmount


class XRPLUptoPayer:
    """Builds and signs the payer's ``CheckCreate`` authorization."""

    def __init__(
        self,
        options: XRPLUptoPayerOptions,
        *,
        client: Optional[JsonRpcClient] = None,
    ) -> None:
        self._options = options
        self._client = client or JsonRpcClient(options.rpc_url)

    def supports(self, req: PaymentRequirements) -> bool:
        if req.scheme != "upto":
            return False
        if req.network not in ("xrpl:0", "xrpl:1", "xrpl:2"):
            return False
        asset = str(req.asset or "XRP")
        if asset.upper() == "XRP":
            return True
        try:
            to_currency_hex(asset)
        except ValueError:
            return False
        extra = req.extra or {}
        issuer = extra.get("issuer") if isinstance(extra, Mapping) else None
        return isinstance(issuer, str) and bool(issuer)

    def authorize(
        self,
        req: PaymentRequirements,
        *,
        invoice_id: Optional[str] = None,
        extensions: Mapping[str, Any] | None = None,
        now: Optional[float] = None,
    ) -> XRPLUptoAuthorization:
        """Sign a ``CheckCreate`` authorizing up to ``req.amount``."""
        if not self.supports(req):
            raise ValueError("PaymentRequirements not supported by XRPLUptoPayer")

        inv = invoice_id or req.invoice_id()
        if not inv:
            raise ValueError("invoiceId is required for the upto scheme")

        ttl = min(int(self._options.authorization_ttl_seconds), int(req.max_timeout_seconds))
        expiration = unix_to_ripple_time((now if now is not None else time.time()) + ttl)

        create_kwargs: dict[str, Any] = {
            "account": self._options.wallet.classic_address,
            "destination": req.pay_to,
            "send_max": _send_max_for_requirements(req),
            "invoice_id": invoice_id_to_invoice_id_field(inv),
            "expiration": expiration,
            "last_ledger_sequence": _ledger_horizon(self._client, req.max_timeout_seconds),
        }
        source_tag = _source_tag_from_requirements(req)
        if source_tag is not None:
            create_kwargs["source_tag"] = source_tag

        tx = CheckCreate(**create_kwargs)

        filled = autofill(tx, self._client)
        signed_blob = sign(filled, self._options.wallet).blob()
        check_id = check_id_from_signed_check_create(signed_blob)

        payment_payload = PaymentPayload(
            x402_version=2,
            resource=None,
            accepted=req,
            payload={
                "signedCheckCreateBlob": signed_blob,
                "invoiceId": inv,
                "checkId": check_id,
            },
            extensions=extensions,
        )
        header = base64.b64encode(
            json.dumps(
                payment_payload.to_dict(), separators=(",", ":"), sort_keys=True
            ).encode("utf-8")
        ).decode("utf-8")

        return XRPLUptoAuthorization(
            payment_payload=payment_payload,
            payment_header=header,
            signed_check_create_blob=signed_blob,
            check_id=check_id,
            invoice_id=inv,
            ceiling=_send_max_for_requirements(req),
        )


@dataclass(frozen=True)
class XRPLUptoMerchantOptions:
    wallet: Wallet
    network: XRPLNetworkId
    rpc_url: str


class XRPLUptoMerchant:
    """Signs the merchant's ``CheckCash`` for the metered amount."""

    def __init__(
        self,
        options: XRPLUptoMerchantOptions,
        *,
        client: Optional[JsonRpcClient] = None,
    ) -> None:
        self._options = options
        self._client = client or JsonRpcClient(options.rpc_url)

    def sign_check_cash(
        self,
        *,
        signed_check_create_blob: str,
        amount: XRPLAmount,
        max_timeout_seconds: int = 600,
        source_tag: Optional[int] = None,
    ) -> str:
        """Sign a ``CheckCash`` cashing the payer's Check for ``amount``.

        ``amount`` is the metered cost. The ledger rejects anything above the
        Check's ``SendMax``, and the facilitator checks it before submitting.

        The ``SourceTag`` is mirrored from the payer's ``CheckCreate`` unless
        overridden. The CheckCash is the settlement-effecting transaction and its
        hash is what the facilitator reports, so it has to carry the same
        attribution tag or reconciliation loses the settling transaction.
        """
        tx_json = xrpl_decode(signed_check_create_blob)
        destination = tx_json.get("Destination")
        if destination != self._options.wallet.classic_address:
            raise ValueError(
                "only the Check's Destination may cash it; "
                f"expected {destination!r}, wallet is "
                f"{self._options.wallet.classic_address!r}"
            )

        check_id = check_id_from_signed_check_create(signed_check_create_blob)

        resolved_source_tag = source_tag
        if resolved_source_tag is None:
            inherited = tx_json.get("SourceTag")
            if inherited is not None:
                resolved_source_tag = int(inherited)

        kwargs: dict[str, Any] = {
            "account": self._options.wallet.classic_address,
            "check_id": check_id,
            "amount": amount,
            "last_ledger_sequence": _ledger_horizon(self._client, max_timeout_seconds),
        }
        if resolved_source_tag is not None:
            kwargs["source_tag"] = resolved_source_tag

        tx = CheckCash(**kwargs)
        filled = autofill(tx, self._client)
        return sign(filled, self._options.wallet).blob()


def build_upto_settle_payload(
    *,
    req: PaymentRequirements,
    signed_check_create_blob: str,
    signed_check_cash_blob: str,
    invoice_id: str,
    extensions: Mapping[str, Any] | None = None,
) -> PaymentPayload:
    """Assemble the settle-time payload carrying both signed artifacts.

    ``req`` here is the CEILING requirement (what the payer signed). The metered
    amount travels separately in the settle request's ``paymentRequirements``.
    """
    return PaymentPayload(
        x402_version=2,
        resource=None,
        accepted=req,
        payload={
            "signedCheckCreateBlob": signed_check_create_blob,
            "signedCheckCashBlob": signed_check_cash_blob,
            "invoiceId": invoice_id,
            "checkId": check_id_from_signed_check_create(signed_check_create_blob),
        },
        extensions=extensions,
    )
