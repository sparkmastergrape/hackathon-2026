from __future__ import annotations

from collections.abc import Mapping
from typing import Any

X402_SECURE_EXTENSION_KEY = "x402Secure"
LEGACY_VERIFIABLE_INTENT_EXTENSION_KEY = "verifiable-intent"

_ALLOWED_PROVIDER_PATCH_KEYS = {"verifiableIntent", "verifiableIntentChain", "ap2", "trace"}
_PROTECTED_VERIFIABLE_INTENT_FIELDS = {
    "policyId",
    "policyVersion",
    "viSessionId",
    "traceId",
    "challengeNonce",
    "requirementToken",
    "decisionToken",
    "trustlineEvidenceSessionId",
}
_PROTECTED_ANYWHERE_FIELDS = {
    "policyId",
    "policyVersion",
    "viSessionId",
    "traceId",
    "challengeNonce",
    "requirementToken",
    "decisionToken",
    "trustlineEvidenceSessionId",
}


def x402_secure_extension(extensions: Mapping[str, Any] | None) -> dict[str, Any]:
    if not isinstance(extensions, Mapping):
        return {}
    value = extensions.get(X402_SECURE_EXTENSION_KEY)
    return dict(value) if isinstance(value, Mapping) else {}


def x402_secure_payment_extensions(
    x402_secure: Mapping[str, Any],
    patch: Mapping[str, Any] | None = None,
) -> dict[str, Any]:
    return {X402_SECURE_EXTENSION_KEY: apply_x402_secure_patch(x402_secure, patch)}


def apply_x402_secure_patch(
    x402_secure: Mapping[str, Any],
    patch: Mapping[str, Any] | None = None,
) -> dict[str, Any]:
    base = _deep_copy_mapping(x402_secure)
    if not patch:
        return base

    if LEGACY_VERIFIABLE_INTENT_EXTENSION_KEY in patch:
        raise ValueError("legacy_verifiable_intent_extension_not_allowed")

    unexpected = set(patch.keys()) - _ALLOWED_PROVIDER_PATCH_KEYS
    if unexpected:
        raise ValueError(f"invalid_x402_secure_patch_keys:{','.join(sorted(unexpected))}")

    _reject_protected_fields(patch)

    for key in _ALLOWED_PROVIDER_PATCH_KEYS:
        value = patch.get(key)
        if value is None:
            continue
        if not isinstance(value, Mapping):
            raise ValueError(f"invalid_x402_secure_patch_section:{key}")
        current = base.get(key)
        if not isinstance(current, Mapping):
            current = {}
        base[key] = _deep_merge(current, value)
    return base


def provider_patch_from_result(result: Mapping[str, Any]) -> Mapping[str, Any]:
    patch = result.get("x402SecurePatch")
    if patch is None:
        patch = result.get("x402_secure_patch")
    if not isinstance(patch, Mapping):
        return {}
    return patch


def _reject_protected_fields(value: Any, *, path: str = "") -> None:
    if isinstance(value, list):
        for idx, child in enumerate(value):
            _reject_protected_fields(child, path=f"{path}{idx}.")
        return
    if not isinstance(value, Mapping):
        return
    for key, child in value.items():
        if key in _PROTECTED_ANYWHERE_FIELDS:
            raise ValueError(f"protected_x402_secure_field:{path + key}")
        if path == "verifiableIntent." and key in _PROTECTED_VERIFIABLE_INTENT_FIELDS:
            raise ValueError(f"protected_x402_secure_field:{path + key}")
        if isinstance(child, (Mapping, list)):
            _reject_protected_fields(child, path=f"{path}{key}.")


def _deep_copy_mapping(value: Mapping[str, Any]) -> dict[str, Any]:
    copied: dict[str, Any] = {}
    for key, child in value.items():
        if isinstance(child, Mapping):
            copied[str(key)] = _deep_copy_mapping(child)
        elif isinstance(child, list):
            copied[str(key)] = [_deep_copy_mapping(v) if isinstance(v, Mapping) else v for v in child]
        else:
            copied[str(key)] = child
    return copied


def _deep_merge(base: Mapping[str, Any], patch: Mapping[str, Any]) -> dict[str, Any]:
    merged = _deep_copy_mapping(base)
    for key, value in patch.items():
        if isinstance(value, Mapping) and isinstance(merged.get(key), Mapping):
            merged[str(key)] = _deep_merge(merged[key], value)  # type: ignore[arg-type]
        elif isinstance(value, Mapping):
            merged[str(key)] = _deep_copy_mapping(value)
        else:
            merged[str(key)] = value
    return merged
