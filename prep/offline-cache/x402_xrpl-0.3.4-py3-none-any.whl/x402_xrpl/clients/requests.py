from __future__ import annotations

import asyncio
import base64
import json
import inspect
import os
import threading
import time
from dataclasses import dataclass
from typing import Any, Callable, Mapping, Sequence

import requests
from xrpl.wallet import Wallet
from xrpl.models.transactions import Transaction

from x402_xrpl.client import XRPLPresignedPaymentPayer, XRPLPresignedPaymentPayerOptions
from x402_xrpl.clients.base import MaxValue, decode_payment_response, x402Client
from x402_xrpl.types import PaymentRequired, PaymentRequirements, ResourceInfo
from x402_xrpl.x402_secure import (
    apply_x402_secure_patch,
    provider_patch_from_result,
    x402_secure_extension,
    x402_secure_payment_extensions,
)

PaymentRequirementsSelector = Callable[
    [Sequence[Mapping[str, Any]], str | None, str | None, MaxValue | None],
    Mapping[str, Any],
]
PaymentHeaderFactory = Callable[..., str]
TransientRetrySleep = Callable[[float], None]


@dataclass(frozen=True)
class X402PurchaseResult:
    status: str
    response: requests.Response | None = None
    reason: str | None = None
    confirmation_request: Mapping[str, Any] | None = None
    payment_response: Mapping[str, Any] | None = None
    transaction: str | None = None
    network: str | None = None
    payer: str | None = None
    extensions: Mapping[str, Any] | None = None
    invoice_id: str | None = None
    retryable: bool | None = None


def _has_header(headers: Mapping[str, Any], name: str) -> bool:
    target = name.lower()
    return any(str(k).lower() == target for k in headers.keys())


def _safe_verify_transient_retry_after(response: requests.Response) -> float | None:
    if response.status_code not in {408, 429} and response.status_code < 500:
        return None
    try:
        body = response.json()
    except Exception:
        return None
    if not isinstance(body, Mapping):
        return None
    if (
        body.get("retryable") is not True
        or body.get("phase") != "verify"
        or body.get("settlementAttempted") is not False
    ):
        return None
    raw = response.headers.get("Retry-After") or body.get("retryAfter") or 30
    try:
        return max(0.0, float(raw))
    except (TypeError, ValueError):
        return 30.0


def _request_paid_with_verify_retries(
    request_fn: Callable[[], requests.Response],
    *,
    max_timeout_seconds: int,
    max_retries: int,
    sleep: TransientRetrySleep,
) -> requests.Response:
    deadline = time.monotonic() + max(0, max_timeout_seconds)
    response = request_fn()
    for _ in range(max(0, max_retries)):
        retry_after = _safe_verify_transient_retry_after(response)
        if retry_after is None or time.monotonic() + retry_after >= deadline:
            break
        sleep(retry_after)
        response = request_fn()
    return response


class X402RequestsSession(requests.Session):
    """
    requests.Session wrapper that auto-handles the x402 flow:

    - Make request
    - If 402 + accepts: select reqs, build PAYMENT-SIGNATURE, retry once
    """

    def __init__(
        self,
        wallet: Wallet,
        *,
        rpc_url: str,
        payment_requirements_selector: PaymentRequirementsSelector = x402Client.default_payment_requirements_selector,
        network_filter: str | None = None,
        scheme_filter: str | None = "exact",
        max_value: MaxValue | None = None,
        invoice_binding: str = "both",
        max_fee_drops: int = 10_000,
        payment_header_factory: PaymentHeaderFactory | None = None,
        verifiable_intent_provider: Any | None = None,
        confirmation_mode: str = "auto",
        user_intent: str | None = None,
        agent_trace: Mapping[str, Any] | None = None,
        x_payment_header: str = "PAYMENT-SIGNATURE",
        transient_verify_retries: int = 2,
        transient_retry_sleep: TransientRetrySleep = time.sleep,
    ) -> None:
        super().__init__()
        self._wallet = wallet
        self._rpc_url = rpc_url
        self._selector = payment_requirements_selector
        self._network_filter = network_filter
        self._scheme_filter = scheme_filter
        self._max_value = max_value
        self._invoice_binding = invoice_binding
        self._max_fee_drops = max_fee_drops
        self._payment_header_factory = payment_header_factory
        self._verifiable_intent_provider = verifiable_intent_provider
        self._confirmation_mode = confirmation_mode
        self._user_intent = user_intent
        self._agent_trace = agent_trace
        self._x_payment_header = x_payment_header
        self._transient_verify_retries = transient_verify_retries
        self._transient_retry_sleep = transient_retry_sleep

    def _build_x_payment(self, reqs: PaymentRequirements, *, extensions: Mapping[str, Any] | None = None, resource: ResourceInfo | None = None) -> str:
        if self._payment_header_factory is not None:
            return _call_payment_header_factory(self._payment_header_factory, reqs, extensions=extensions, resource=resource)

        payer = XRPLPresignedPaymentPayer(
            XRPLPresignedPaymentPayerOptions(
                wallet=self._wallet,
                network=reqs.network,  # type: ignore[arg-type]
                rpc_url=self._rpc_url,
                invoice_binding=self._invoice_binding,  # type: ignore[arg-type]
                max_fee_drops=self._max_fee_drops,
            )
        )
        return payer.create_payment_header(reqs, extensions=extensions, resource=resource)

    def request(self, method: str, url: str, **kwargs: Any) -> requests.Response:
        headers_in = dict(kwargs.get("headers") or {})
        other_kwargs = {k: v for k, v in kwargs.items() if k != "headers"}

        resp = super().request(method, url, headers=headers_in, **other_kwargs)
        if resp.status_code != 402:
            return resp

        # Don’t override a caller-supplied payment header
        if _has_header(headers_in, self._x_payment_header):
            return resp

        try:
            body = resp.json()
        except Exception:
            return resp
        if not isinstance(body, dict):
            return resp

        accepts: list[Mapping[str, Any]] = []

        raw_accepts = body.get("accepts")
        if isinstance(raw_accepts, list):
            accepts.extend([a for a in raw_accepts if isinstance(a, Mapping)])

        if not accepts:
            return resp

        try:
            selected = self._selector(
                accepts,
                self._network_filter,
                self._scheme_filter,
                self._max_value,
            )
            reqs = PaymentRequirements.from_dict(selected)
            if self._network_filter and reqs.network != self._network_filter:
                raise ValueError("payment_network_mismatch")
            payment_extensions = _prepare_payment_extensions(
                body=body,
                reqs=reqs,
                provider=self._verifiable_intent_provider,
                confirmation_mode=self._confirmation_mode,
                user_intent=self._user_intent,
                agent_trace=self._agent_trace,
            )
            if payment_extensions is False:
                return resp
            x_payment = self._build_x_payment(
                reqs,
                extensions=payment_extensions if isinstance(payment_extensions, Mapping) else None,
                resource=ResourceInfo.from_dict(body["resource"]) if isinstance(body.get("resource"), Mapping) else None,
            )
        except Exception:
            # Fail open: return the original 402 so callers can inspect/handle it.
            return resp

        headers_retry = dict(headers_in)
        headers_retry[self._x_payment_header] = x_payment
        return _request_paid_with_verify_retries(
            lambda: super(X402RequestsSession, self).request(
                method,
                url,
                headers=headers_retry,
                **other_kwargs,
            ),
            max_timeout_seconds=reqs.max_timeout_seconds,
            max_retries=self._transient_verify_retries,
            sleep=self._transient_retry_sleep,
        )


def x402_requests(
    wallet: Wallet,
    *,
    rpc_url: str | None = None,
    payment_requirements_selector: PaymentRequirementsSelector = x402Client.default_payment_requirements_selector,
    network_filter: str | None = None,
    scheme_filter: str | None = "exact",
    max_value: MaxValue | None = None,
    invoice_binding: str = "both",
    max_fee_drops: int = 10_000,
    payment_header_factory: PaymentHeaderFactory | None = None,
    verifiable_intent_provider: Any | None = None,
    confirmation_mode: str = "auto",
    user_intent: str | None = None,
    agent_trace: Mapping[str, Any] | None = None,
    transient_verify_retries: int = 2,
    transient_retry_sleep: TransientRetrySleep = time.sleep,
) -> X402RequestsSession:
    """
    Construct a requests.Session that auto-handles x402 on XRPL.

    Typical usage:
      session = x402_requests(wallet, rpc_url=..., network_filter="xrpl:1")
      resp = session.get(url)
    """
    rpc_url = rpc_url or os.getenv("XRPL_RPC_URL") or os.getenv("XRPL_TESTNET_RPC_URL")
    if not rpc_url:
        raise ValueError("rpc_url is required (pass rpc_url=... or set XRPL_RPC_URL)")

    return X402RequestsSession(
        wallet,
        rpc_url=rpc_url,
        payment_requirements_selector=payment_requirements_selector,
        network_filter=network_filter,
        scheme_filter=scheme_filter,
        max_value=max_value,
        invoice_binding=invoice_binding,
        max_fee_drops=max_fee_drops,
        payment_header_factory=payment_header_factory,
        verifiable_intent_provider=verifiable_intent_provider,
        confirmation_mode=confirmation_mode,
        user_intent=user_intent,
        agent_trace=agent_trace,
        transient_verify_retries=transient_verify_retries,
        transient_retry_sleep=transient_retry_sleep,
    )


def x402_purchase(
    url: str,
    *,
    wallet: Wallet,
    rpc_url: str | None = None,
    method: str = "GET",
    headers: Mapping[str, str] | None = None,
    payment_requirements_selector: PaymentRequirementsSelector = x402Client.default_payment_requirements_selector,
    network_filter: str | None = None,
    scheme_filter: str | None = "exact",
    max_value: MaxValue | None = None,
    invoice_binding: str = "both",
    max_fee_drops: int = 10_000,
    payment_header_factory: PaymentHeaderFactory | None = None,
    verifiable_intent_provider: Any | None = None,
    confirmation_mode: str = "auto",
    user_intent: str | None = None,
    agent_trace: Mapping[str, Any] | None = None,
    x_payment_header: str = "PAYMENT-SIGNATURE",
    transient_verify_retries: int = 2,
    transient_retry_sleep: TransientRetrySleep = time.sleep,
    session: requests.Session | None = None,
    **request_kwargs: Any,
) -> X402PurchaseResult:
    rpc_url = rpc_url or os.getenv("XRPL_RPC_URL") or os.getenv("XRPL_TESTNET_RPC_URL")
    if not rpc_url:
        return X402PurchaseResult(status="failed", reason="rpc_url_required")

    sess = session or requests.Session()
    headers_in = dict(headers or {})
    try:
        first_resp = sess.request(method, url, headers=headers_in, **request_kwargs)
    except Exception as exc:
        return X402PurchaseResult(status="failed", reason=str(exc))

    if first_resp.status_code != 402:
        return X402PurchaseResult(status="success", response=first_resp)

    try:
        body = first_resp.json()
    except Exception:
        return X402PurchaseResult(status="payment_required", response=first_resp, reason="invalid_payment_required")
    if not isinstance(body, dict):
        return X402PurchaseResult(status="payment_required", response=first_resp, reason="invalid_payment_required")

    raw_accepts = body.get("accepts")
    accepts = [a for a in raw_accepts if isinstance(a, Mapping)] if isinstance(raw_accepts, list) else []
    if not accepts:
        return X402PurchaseResult(status="payment_required", response=first_resp, reason="no_accepts")

    try:
        selected = payment_requirements_selector(accepts, network_filter, scheme_filter, max_value)
        reqs = PaymentRequirements.from_dict(selected)
        if network_filter and reqs.network != network_filter:
            raise ValueError("payment_network_mismatch")
    except Exception as exc:
        return X402PurchaseResult(status="payment_required", response=first_resp, reason=str(exc))

    try:
        provider_result = _prepare_provider_result(
            body=body,
            reqs=reqs,
            provider=verifiable_intent_provider,
            confirmation_mode=confirmation_mode,
            user_intent=user_intent,
            agent_trace=agent_trace,
        )
    except Exception as exc:
        return X402PurchaseResult(status="failed", response=first_resp, reason=str(exc))

    if provider_result and provider_result.get("status") == "requires_confirmation":
        return X402PurchaseResult(
            status="requires_confirmation",
            response=first_resp,
            reason=str(provider_result.get("reason") or ""),
            confirmation_request=provider_result.get("confirmationRequest")
            if isinstance(provider_result.get("confirmationRequest"), Mapping)
            else provider_result.get("confirmation_request")
            if isinstance(provider_result.get("confirmation_request"), Mapping)
            else None,
        )
    if provider_result and provider_result.get("status") == "declined":
        return X402PurchaseResult(
            status="declined",
            response=first_resp,
            reason=str(provider_result.get("reason") or ""),
        )

    try:
        payment_extensions = _payment_extensions_from_provider_result(
            body,
            provider_result,
            provider=verifiable_intent_provider,
        )
        resource = ResourceInfo.from_dict(body["resource"]) if isinstance(body.get("resource"), Mapping) else None
        if payment_header_factory is not None:
            x_payment = _call_payment_header_factory(payment_header_factory, reqs, extensions=payment_extensions, resource=resource)
        else:
            payer = XRPLPresignedPaymentPayer(
                XRPLPresignedPaymentPayerOptions(
                    wallet=wallet,
                    network=reqs.network,  # type: ignore[arg-type]
                    rpc_url=rpc_url,
                    invoice_binding=invoice_binding,  # type: ignore[arg-type]
                    max_fee_drops=max_fee_drops,
                )
            )
            x_payment = payer.create_payment_header(reqs, extensions=payment_extensions, resource=resource)
    except Exception as exc:
        return X402PurchaseResult(status="failed", response=first_resp, reason=str(exc))

    retry_headers = dict(headers_in)
    retry_headers[x_payment_header] = x_payment
    try:
        paid_resp = _request_paid_with_verify_retries(
            lambda: sess.request(method, url, headers=retry_headers, **request_kwargs),
            max_timeout_seconds=reqs.max_timeout_seconds,
            max_retries=transient_verify_retries,
            sleep=transient_retry_sleep,
        )
    except Exception:
        return _unknown_settlement(x_payment, reqs, first_resp, "payment_response_unavailable")

    payment_response = None
    transaction = network = payer = None
    extensions = None
    if "PAYMENT-RESPONSE" in paid_resp.headers:
        try:
            payment_response = decode_payment_response(paid_resp.headers["PAYMENT-RESPONSE"])
            transaction = payment_response.get("transaction")
            network = payment_response.get("network")
            payer = payment_response.get("payer")
            extensions = payment_response.get("extensions")
        except (TypeError, ValueError):
            return _unknown_settlement(x_payment, reqs, paid_resp, "invalid_payment_response")
        if payment_response["success"] is False:
            return X402PurchaseResult(
                status="settle_failed", response=paid_resp,
                reason=payment_response.get("errorReason") or "settlement_failed",
                payment_response=payment_response, transaction=transaction,
                network=network, payer=payer, extensions=extensions,
            )

    if paid_resp.status_code == 402:
        return X402PurchaseResult(status="payment_required", response=paid_resp)
    if paid_resp.status_code >= 400:
        return X402PurchaseResult(status="failed", response=paid_resp, reason=f"http_{paid_resp.status_code}")

    return X402PurchaseResult(
        status="success", response=paid_resp, payment_response=payment_response,
        transaction=transaction, network=network, payer=payer, extensions=extensions,
    )


def _unknown_settlement(header: str, reqs: PaymentRequirements, response: requests.Response, reason: str) -> X402PurchaseResult:
    transaction = None
    try:
        payload = json.loads(base64.b64decode(header))["payload"]
        transaction = Transaction.from_blob(payload["signedTxBlob"]).get_hash()
    except Exception:
        # Recovery metadata is best effort for custom header factories.
        pass
    return X402PurchaseResult(
        status="settlement_unknown", reason=reason, retryable=False, response=response,
        transaction=transaction, network=reqs.network, invoice_id=reqs.invoice_id(),
    )


def _call_payment_header_factory(
    factory: PaymentHeaderFactory,
    reqs: PaymentRequirements,
    *,
    extensions: Mapping[str, Any] | None,
    resource: ResourceInfo | None = None,
) -> str:
    kwargs: dict[str, Any] = {}
    if extensions is not None and _factory_accepts_parameter(factory, "extensions"):
        kwargs["extensions"] = extensions
    if resource is not None and _factory_accepts_parameter(factory, "resource"):
        kwargs["resource"] = resource
    return factory(reqs, **kwargs)


def _factory_accepts_parameter(factory: PaymentHeaderFactory, key: str) -> bool:
    try:
        signature = inspect.signature(factory)
    except (TypeError, ValueError):
        return True
    for name, parameter in signature.parameters.items():
        if parameter.kind == inspect.Parameter.VAR_KEYWORD:
            return True
        if name == key and parameter.kind in {
            inspect.Parameter.KEYWORD_ONLY,
            inspect.Parameter.POSITIONAL_OR_KEYWORD,
        }:
            return True
    return False


def _prepare_payment_extensions(
    *,
    body: Mapping[str, Any],
    reqs: PaymentRequirements,
    provider: Any | None,
    confirmation_mode: str,
    user_intent: str | None,
    agent_trace: Mapping[str, Any] | None,
) -> Mapping[str, Any] | bool | None:
    provider_result = _prepare_provider_result(
        body=body,
        reqs=reqs,
        provider=provider,
        confirmation_mode=confirmation_mode,
        user_intent=user_intent,
        agent_trace=agent_trace,
    )
    if provider_result and provider_result.get("status") != "ready":
        return False
    return _payment_extensions_from_provider_result(body, provider_result, provider=provider)


def _prepare_provider_result(
    *,
    body: Mapping[str, Any],
    reqs: PaymentRequirements,
    provider: Any | None,
    confirmation_mode: str,
    user_intent: str | None,
    agent_trace: Mapping[str, Any] | None,
) -> Mapping[str, Any] | None:
    payment_required = PaymentRequired.from_dict(body)
    secure = _x402_secure_envelope_for_provider(payment_required, provider)
    if not secure:
        return None
    if provider is None:
        return {"status": "requires_confirmation", "reason": "verifiable_intent_provider_required"}
    method = getattr(provider, "prepare_evidence", None) or getattr(provider, "prepareEvidence", None)
    if method is None:
        raise ValueError("verifiable_intent_provider_missing_prepare_evidence")
    result = method(
        {
            "userIntent": user_intent,
            "confirmationMode": confirmation_mode,
            "paymentRequired": payment_required,
            "selectedPaymentRequirements": reqs,
            "x402Secure": secure,
            "agentTrace": dict(agent_trace or {}),
        }
    )
    if inspect.isawaitable(result):
        result = _run_awaitable_sync(result)
    if not isinstance(result, Mapping):
        raise ValueError("invalid_verifiable_intent_provider_result")
    return result


def _run_awaitable_sync(awaitable: Any) -> Any:
    try:
        asyncio.get_running_loop()
    except RuntimeError:
        return asyncio.run(awaitable)

    box: dict[str, Any] = {}

    def _runner() -> None:
        try:
            box["result"] = asyncio.run(awaitable)
        except BaseException as exc:  # noqa: BLE001
            box["error"] = exc

    thread = threading.Thread(target=_runner, name="x402-vi-provider", daemon=True)
    thread.start()
    thread.join()
    if "error" in box:
        raise box["error"]
    return box.get("result")


def _payment_extensions_from_provider_result(
    body: Mapping[str, Any],
    provider_result: Mapping[str, Any] | None,
    *,
    provider: Any | None = None,
) -> Mapping[str, Any] | None:
    payment_required = PaymentRequired.from_dict(body)
    secure = _x402_secure_envelope_for_provider(payment_required, provider)
    if not secure:
        return None
    if provider_result is None:
        return None
    patch = provider_patch_from_result(provider_result)
    merged = apply_x402_secure_patch(secure, patch)
    return x402_secure_payment_extensions(merged)


def _x402_secure_envelope_for_provider(
    payment_required: PaymentRequired,
    provider: Any | None,
) -> Mapping[str, Any]:
    secure = x402_secure_extension(payment_required.extensions)
    if secure:
        return secure
    # Merchant did NOT declare x402Secure in its 402: do not fabricate an envelope just
    # because a verifiable_intent_provider is supplied. Fabricating one (with mode
    # "enforce") made payers attach an orphan VI chain to plain merchants, which trips the
    # facilitator's settle-time VI gate demanding a decisionToken that can never be issued
    # (the merchant never ran the verify handshake). No merchant declaration => no
    # x402-secure for this payment; the provider seam stays genuinely merchant-conditional.
    return {}
